<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/LocationAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    if(isset($_GET['loc'])){
        doGetSpecific();
    }
    elseif(isset($_GET['dist'])){
        doGetDistance();
    }
    else{
    doGetLocation();
    }
}
//if post and first name goes make a new user
else if ($method==="POST"){
    doCreate();
}
//if put do an update
else if($method==="PUT"){
    doUpdateLocation();
}
//if delete apply locked
else if($method==="DELETE"){
     doDelete();
}
function doGetDistance(){
    $la = new LocationAccessor();
    $result=$la->getWareDist($_GET['dist']);
    echo $result;
}
function doDelete() {
    if (isset($_GET['id'])) { 
        $id = $_GET['id']; 
        // delete the object from DB
        $ua = new LocationAccessor();
        $dum = new Location($id,"l", "l", "l","l","l","l","l","l","l", "l", 1);
        $success = $ua->ExplodeLocation($dum);
        echo $success;
    } else {
        echo $ex;
    }
}
function doGetSpecific(){
        try {
            $ur = new LocationAccessor();
            $results = $ur->getLocation($_GET['loc']);
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doGetLocation(){
        try {
            $ur = new LocationAccessor();
            $results = $ur->getAllLocations();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doUpdateLocation()
{   try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new LocationAccessor();
    $id=$contents['id'];
    $name = $contents['name'];
    $province=$contents['province'];
    $address=$contents['address'];
    $city=$contents['city'];
    $post=$contents['post'];
    $distance=$contents['dist'];
    $phone=$contents['phone'];
    $day=$contents['day'];
    $type=$contents['type'];
    $active=$contents['active'];
    $userPerson = new Location($id,$name,$province,$address,$city,'Canada', $post, $phone,$day, $distance, $type, $active);
    $success = $ua->updateLocation($userPerson); 
    if ($success){
        echo $success;
      }
    }
catch (PDOException $e) {
    $success = false;
    echo $e->getMessage();
    } 
}

function doCreate(){
try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new LocationAccessor();
    $name = $contents['name'];
    $province=$contents['province'];
    $address=$contents['address'];
    $city=$contents['city'];
    $post=$contents['post'];
    $distance=$contents['dist'];
    $phone=$contents['phone'];
    $day=$contents['day'];
    $type=$contents['type'];
    $userPerson = new Location(0,$name,$province,$address,$city,'Canada', $post, $phone,$day, $distance, $type, 1);
    $success = $ua->insertLocation($userPerson); 
    if ($success){
        echo $success;
        }
    else
       {
        echo $success;
       }
} catch (PDOException $e) {
    $success = true;
    echo $e->getMessage();
}
}