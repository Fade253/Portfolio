<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/orderAccessor.php';
require_once '../db/itemAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    if(isset($_GET['saved'])){
        doGetOrderFromLocation($_GET['saved']);
    }
    elseif(isset($_GET['i'])){
        setSession();
    }
    elseif(isset($_GET['id'])){
        doGetOrderItems();
    }
    else{
    doGetOrders();
    }
}
//if post and first name goes make a new user
else if ($method==="POST"){
    if(isset($_GET['red'])){
        doChangeOrder();
    }
    else{
    dopickup();
    }
}
else if ($method==='CANCEL'){
    doCancel();
}
//if put do an update
else if($method==="PUT"){
    if(isset($_GET['idi'])){
        doDeliver();
    }
    else if(isset($_GET['id'])){  
      dotransport();
    }
    else if (isset($_GET['id3'])){
        doDelete();
    }
    else if(isset($_GET['id2'])){
        doCancel();
    }
    else if(isset($_GET['finalized'])){
        doSubmit();
    }
    elseif(isset($_GET['txnID'])){
        doAccept();
    }
    else{
        updateOrder();
    }
}
else if($method=="DELETE"){
    doremoveItem();
}
function doAccept(){
    $oa=new orderAccessor();
    $result=$oa->Complete($_GET['txnID']);
    echo json_encode($result, JSON_NUMERIC_CHECK);
}
function doSubmit(){
    $oa=new orderAccessor();
    $id=$oa->getOrderId($_GET['finalized']);
    $result=$oa->submitOrder($id);
    echo $result;
}
function doremoveItem(){
    try{
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $oa=new orderAccessor();
    $ia=new itemAccessor();
    $id=$oa->getOrderId($contents['loc']);
    $item=$contents['id'];
    $ia->removeFromOrder($id, $item);
    echo 1;
    }
    catch(Exception $ex){
        echo $ex->getMessage();
    }
}
function doChangeOrder(){
    try{
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);
        $items = $contents['item'];
        $quantity=$contents['quantity'];
        $oa=new orderAccessor();
        $result=$oa->updateOrder($_GET['red'],$items, $quantity);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function setSession(){
    try{
        $_SESSION['txn']=$_GET['i'];
        echo 1;
    } catch (Exception $ex) {
        $ex->getMessage();
    }
}
//if delete apply locked
function dotransport(){
    try{
    $oa=new orderAccessor();
    $results=$oa->Transport($_GET['id']);
    echo $results;
    }
    catch (Exception $e){
        echo $e->getMessage();
    }
}
function doDeliver(){
        try {
            $ur = new orderAccessor();
            $results = $ur->Deliver($_GET['idi']);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function dopickup(){
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);
        $id=$contents['id'];
        $distance=$contents['distance'];
        $size=$contents['size'];
        // delete the object from DB
        $ua = new orderAccessor();
        $success = $ua->pickup($id, $distance, $size);
        echo $success;
}
function doCancel(){
    if($_GET['id2']) {
        // delete the object from DB
        $ua = new orderAccessor();
        $success = $ua->Cancel($_GET['id2']);
        echo $success;
    }  
}
function doGetOrders(){
        try {
            $ur = new orderAccessor();
            $results = $ur->getAllOrders();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doGetOrderItems(){
        try {
            $ur = new orderAccessor();
            if(isset($_GET['idp'])){
                $results=$ur->getOrderItemss($_GET['id'], $_GET['idp']);
            }
            else{
            $results = $ur->getOrderItems($_GET['id']);
            }
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doGetOrderFromLocation($location){
        try {
            $ur = new orderAccessor();
            $id=$ur->getOrderId($location);
            $results = $ur->getOrderItems($id);
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
