<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/inventoryAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    doGetQuantity();
}
if ($method==="PUT"){
    doChangeThresh();
}
function doChangeThresh(){
    try{
    $ur = new inventoryAccessor();
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $item=$contents['item'];
    $reorder=$contents['reorder'];
    $results = $ur->updateThreshold($item, $reorder);
    echo $results;
    }
    catch (Exception $e){
        echo "ERROR " . $e->getMessage();
    }
}
function doGetInventory(){
        try {
            $ur = new inventoryAccessor();
            $results = $ur->getQuantity($_GET[$id]);
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
