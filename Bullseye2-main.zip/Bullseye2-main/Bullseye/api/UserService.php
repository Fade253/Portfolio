<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/UserAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    doGrabUsers();
}
//if post and first name goes make a new user
else if ($method==="POST"&&isset($_GET["first"])){
    doRegister();
}
//if password sent update password
else if ($method==="POST"&&isset($_GET["password"])){
    UpdatePassword();
}
//if email sent check email exists
else if ($method==="POST"&&isset($_GET["email"])){
   doVerify();    
}
//if nothing is set log in
else if ($method==="POST"&&!isset($_GET["email"])&&!isset($_GET["password"])&&!isset($_GET["first"]))
{
    if(isset($_GET['logout'])){
        dologout();
    }
    else{
     doLogin();   
    }
}
//if put do an update
else if($method==="PUT"){
    if (isset($_GET['first'])){
    doUpdateUser();}
    else if (isset($_GET["username"])){
        doDelete();
    }
}
function doLogout(){
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $date=$contents["date"];
    $user = $_SESSION['user'];
    $ua = new UserAccessor();
    $success=$ua->Logout($user);
    echo $success;
}
//if delete apply locked
function UpdatePassword(){
       $body = file_get_contents('php://input');
       $contents = json_decode($body, true);
       $date=$contents["date"];
    if(isset($_GET["password"])){
        $password=md5($_GET["password"]);
        $ua = new UserAccessor();
        $success = $ua->changepassword($password, $date);
        echo $success;
    }
}
function doVerify(){
    if(isset($_GET["email"])){
        $email = $_GET['email'];
        $ua = new UserAccessor();
        $success = $ua->getUserByEmail($email);
        $_SESSION['email']=$email;
        if($success->getEmail()==$email){
            echo "1";
        }
        else {
            echo $success;
        }
    }
}
function doDelete() {
    if (isset($_GET['username'])) { 
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);
        $date=$contents['date'];
        $user = $_GET['username']; 
        // delete the object from DB
        $ua = new UserAccessor();
        $dum = new User(0,$user, "no", "dumb","dumb","be",0,0,1,1);
        $success = $ua->deleteUser($dum,$date);
        #$audit = fopen("Audit.txt", "w");
        #fwrite($audit, "admin has 'deleted' a user");
        #fclose($audit);
        echo $success;
    } else {
        echo "i dont want to";
    }
}
function doGrabUsers(){
        try {
            $ur = new UserAccessor();
            $results = $ur->getAllUsers();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doUpdateUser()
{   try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new UserAccessor();
    $username = strtolower(substr($contents["first"], 0,1).$contents['last']);
    ChromePhp::log($username);
    $id=$contents['id'];
    $first= $contents['first'];
    $last = $contents['last'];
    $date=$contents['date'];
    $email=$username."@bullseye.ca";
    $active=1;
    $locked=0;
    $posID=$contents['position'];
    $site=$contents['site'];
    $passReal = md5($contents['password']);
    $userPerson = new User($id,$username,$passReal,$first,$last, $email, $active,$locked,$posID,$site);
    $success = $ua->updateUser($userPerson, $date); 
    if ($success){
        echo $success;
      }
    }
catch (PDOException $e) {
    $success = false;
    echo $e->getMessage();
    } 
}
function doLogin(){
    try {
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);
        $bool = false;
        ChromePhp::log($body);
        $username = $contents["username"];
        $password = md5($contents["password"]);
        $date=$contents["date"];
        $uc = new UserAccessor();
        $user = $uc->getUserByUsername($username, $date);
        //$passReal = password_hash($contents['password'], PASSWORD_DEFAULT);
    if ($password === $user->getPassword()) {
        $bool = true;
    } else {
        $bool = false;
    }
    $passwords = [$password, $user->getPassword(), $bool];
    $resultsA = json_encode($passwords, JSON_NUMERIC_CHECK);
    $_SESSION["username"] = json_encode($user, JSON_NUMERIC_CHECK);
} 
catch (PDOException $e) {
    echo $e->getMessage();
}
echo $bool;
}

function doRegister(){
try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new UserAccessor();
    $date=$contents['date'];
    $username = substr($_GET["first"], 0,1).$contents['last'];
    $first= $contents['first'];
    $last = $contents['last'];
    $email=$username."@bullseye.ca";
    $active=1;
    $locked=0;
    $posID=$contents['position'];
    $site=$contents['site'];
    $passReal = md5($contents['password']);
    $userPerson = new User(0,$username,$passReal,$first,$last, $email, $active,$locked,$posID,$site);
    $success = $ua->insertUser($userPerson, $date); 
    if ($success){
        echo $success;
        }
    else
       {
        echo $success;
       }
} catch (PDOException $e) {
    $success = true;
    echo $e->getMessage();
}
}