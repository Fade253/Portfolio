<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/orderAccessor.php';
require_once '../db/itemAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
        doGetSupplierItems();
}
//if post and first name goes make a new user
else if ($method==="POST"){
        doSupplierOrder();
}
//if put do an update
else if($method==="PUT"){
    doUpdateLocation();
}
//if delete apply locked
else if($method==="DELETE"){
     doDelete();
}
function doGetSuppliers(){
    try{
    $ia=new itemAccessor();
    $result=$ia->getSuppliers();
    $result= json_encode($result, JSON_NUMERIC_CHECK);
    echo $result;
    }
    catch(PDOException $ex){
        echo $ex->getMessage();
    }
}
function doSupplierOrder(){
    try{
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ship=$contents['ship'];
    $oa = new orderAccessor();
    $success=$oa->SupplierOrder($ship);
    echo $success;
    }
    catch (Exception $ex){
        echo $ex->getMessage();
    }
}
function doGetSupplierItems(){
    try{
        $ia=new itemAccessor();
        $result=$ia->getSupplierItems();
        $result=json_encode($result, JSON_NUMERIC_CHECK);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function doCreate(){
    try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new orderAccessor();
    $place = $contents['place'];
    $em=$contents['emergency'];
    $ship=$contents['ship'];
    $userPerson = new order(0,$place,0,0,$ship,0, 0, 0,$em);
    $success = $ua->Order($userPerson); 
    echo $success;    
} catch (PDOException $e) {
    echo $e->getMessage();
}
}
function doCheckOrder(){
        try {
            $ur = new orderAccessor();
            $results = $ur->checkTransaction($_GET['local']);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doGetOrders(){
        try {
            $ur = new orderAccessor();
            $results = $ur->getAllLocations();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
