<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/ReportAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    if(isset($_GET['dev'])){
        doDeliveryReport();
    }
    elseif(isset($_GET['back'])){
        doBackOrderReport();
    }
    elseif(isset($_GET['store'])){
        doStoreOrderReport();
    }
    elseif(isset($_GET['loss'])){
        doLossReport();
    }
    elseif(isset($_GET['inven'])){
        doInventoryReport();
    }
    elseif(isset($_GET['eme'])){
        doEmergencyOrderReport();
    }
    elseif(isset($_GET['user'])){
        doUserReport();
    }
    elseif(isset($_GET['supp'])){
        doSupplierOrder();
    }
    else{
    doGetReports();
    }
}
function doLossReport(){
    $ra = new ReportAccessor();
    $result=$ra->getLosses($_GET['loss']);
    $result= json_encode($result, JSON_NUMERIC_CHECK);
    echo $result;
}
function doInventoryReport(){
    $ra=new ReportAccessor();
    $result=$ra->getAllInventory($_GET['inven']);
    $result=json_encode($result, JSON_NUMERIC_CHECK);
    echo $result;
}
function doUserReport(){
    $ra=new ReportAccessor();
    $result=$ra->getUserReport();
    $result= json_encode($result, JSON_NUMERIC_CHECK);
    echo $result;
}
function doBackOrderReport(){
    try{
        $ra=new ReportAccessor();
        $start=$_GET['back'];
        $result=$ra->getBackOrder($start);
        $result= json_encode($result, JSON_NUMERIC_CHECK);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function doStoreOrderReport(){
    try{
        $ra=new ReportAccessor();
        $start=$_GET['store'];
        $result=$ra->getStoreOrder($start);
        $result= json_encode($result, JSON_NUMERIC_CHECK);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function doSupplierOrder(){
    try{
        $ra=new ReportAccessor();
        $start=$_GET['supp'];
        $result=$ra->getStoreOrder($start);
        $result= json_encode($result, JSON_NUMERIC_CHECK);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function doEmergencyOrderReport(){
    try{
        $ra=new ReportAccessor();
        $start=$_GET['eme'];
        $result=$ra->getEmergencyOrder($start);
        $result= json_encode($result, JSON_NUMERIC_CHECK);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function doGetReports(){
        try {
            $ur = new reportAccessor();
            $results = $ur->getAllReports();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doDeliveryReport(){
      try{
          $start=$_GET['dev'];
          $ra=new ReportAccessor();
          $result=$ra->getDelivery($start);
          $result= json_encode($result, JSON_NUMERIC_CHECK);
          echo $result;
      } catch (Exception $ex) {
          echo $ex->getMessage();
      }
}