<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/orderAccessor.php';
require_once '../db/itemAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
        doGetOperations();
}
//if post and first name goes make a new user
else if ($method==="POST"){
    doCreate();
}
else if ($method=="PUT"){
        doRemoveInventory();
    
}
function doCreate(){
    try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new orderAccessor();
    $place = $contents['place'];
    $em=$contents['type'];
    $ship=$contents['note'];
    $success = $ua->operation($place, $em, $ship); 
    echo $success;    
} catch (PDOException $e) {
    echo $e->getMessage();
}
}
function doGetOperations(){
        try {
            $ur = new orderAccessor();
            $results = $ur->getAllOperations();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}

function doRemoveInventory(){
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $items=$contents['items'];
    $quantitys=$contents['quantity'];
    $bool=$contents['bool'];
    $loc=$_SESSION['site'];
    $oa=new orderAccessor();
    $result=$oa->applyItems($items, $quantitys, $bool, $loc);
    echo $result;
}

