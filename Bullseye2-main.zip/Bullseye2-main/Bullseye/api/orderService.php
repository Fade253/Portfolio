<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/orderAccessor.php';
require_once '../db/itemAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    if(isset($_GET['local'])){
        doCheckOrder();
    }
    else if(isset($_GET['txn'])){
        doGetTxnItems();
    }
    elseif(isset($_GET['final'])){
        doReadyOrder();
    }
    elseif(isset($_GET['onloc'])){
        doGetOnlineOrders();
    }
    elseif(isset($_GET['name'])){
        doGetOnlineOrder();
    }
    else{
    doGetOrders();
    }
}
//if post and first name goes make a new user
else if ($method==="POST"){
    if(isset($_GET['items'])){
        doPutItems();
    }
    elseif(isset($_GET['back'])){
        doBackOrder();
    }
    else{
    doCreate();
}
}
//if put do an update
else if($method==="PUT"){
    doUpdateLocation();
}
//if delete apply locked
else if($method==="DELETE"){
     doDelete();
}
function doGetOnlineOrders(){
    $oa = new orderAccessor();
    $results = $oa->getOnlineOrders($_GET['onloc']);
    $results = json_encode($results, JSON_NUMERIC_CHECK);
    echo $results; 
}
function doGetOnlineOrder(){
    $oa = new orderAccessor();
    $results = $oa->getOnlineOrder($_GET['name']);
    $results = json_encode($results, JSON_NUMERIC_CHECK);
    echo $results; 
}
function doReadyOrder(){
    try{
    $_GET['final'];
    $oa = new orderAccessor();
    $success=$oa->Ready($_GET['final']);
    echo $success;
    }
    catch (Exception $ex){
        echo $ex->getMessage();
    }
}
function doDelete() {
    if (isset($_GET['id'])) { 
        $id = $_GET['id']; 
        // delete the object from DB
        $ua = new LocationAccessor();
        $dum = new Location($id,"l", "l", "l","l","l","l","l","l","l", "l", 1);
        $success = $ua->ExplodeLocation($dum);
        echo $success;
    } else {
        echo $ex;
    }
}
function doGetTxnItems(){
    try{
        $ia=new itemAccessor();
        $result=$ia->getTxnItems($_GET['txn']);
        $result=json_encode($result, JSON_NUMERIC_CHECK);
        echo $result;
    } catch (Exception $ex) {
        echo $ex->getMessage();
    }
}
function doBackOrder(){
    try{
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $id=$_GET['back'];
    $items=$contents['item'];
    $quantitys=$contents['quantity'];
    $oa= new orderAccessor();
    $success=$oa->backOrder($id, $items, $quantitys);
    echo $success;
    }
    catch(Exception $ex){
        echo "ERROR ".$ex->getMessage();
    }
}
function doPutItems(){
    try{
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $oa= new orderAccessor();
    $items=$contents['items'];
    $quantity=$contents['quantity'];
    $success=$oa->applyItems($items, $quantity);
    echo $success;
    }
    catch(Exception $e){
        echo $e->getMessage();
    }
}
function doCreate(){
    try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new orderAccessor();
    $place = $contents['place'];
    $em=$contents['emergency'];
    $ship=$contents['ship'];
    $userPerson = new order(0,$place,0,0,$ship,0, 0, 0,$em);
    $success = $ua->Order($userPerson); 
    echo $success;    
} catch (PDOException $e) {
    echo $e->getMessage();
}
}
function doCheckOrder(){
        try {
            $ur = new orderAccessor();
            $results = $ur->checkTransaction($_GET['local']);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doGetOrders(){
        try {
            $ur = new orderAccessor();
            $results = $ur->getAllLocations();
            $results = json_encode($results, JSON_NUMERIC_CHECK);
            echo $results;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}


