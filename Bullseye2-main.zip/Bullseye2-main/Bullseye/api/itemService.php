<?php
session_start();
include '../db/ChromePhp.php';
require_once '../db/DatabaseConnecter.php';
require_once '../db/ItemAccessor.php';
$method = $_SERVER['REQUEST_METHOD'];
//if get grab users
if ($method==="GET"){
    if(isset($_GET['local'])){   
        doGetLocInv();
    }
    else if(isset($_GET['ware'])){
        doGetWarehouse();
    }
    else{
    doGetSupply();
    }
}
else if ($method==="POST"){
    if (isset($_GET['search'])){
        doGetSearch();
    }
    else if (isset($_GET['loc'])){
        doGetInvItem();
    }
    else{
    doCreate();
    }
}
//if put do an update
else if($method==="PUT"){
    if(isset($_GET['id'])){
    doDelete();
    }
    else if(isset($_GET['txnID'])){
        doMoveItem();
    }
    elseif(isset($_GET['trans'])){
        doMoveOnlineItem();
    }
    else{
        doUpdateItem();
    }
}
function doMoveOnlineItem(){
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $items=$contents['item'];
    $quantitys=$contents['quantity'];
    $loc=$contents['loc'];
    $count=0;
    while($count<count($items)){
            $ia=new itemAccessor();
            $ia->moveOnlineItem($loc, $items[$count], $quantitys[$count]);
            $count=$count+1;
    }
    echo 1;
}
function doMoveItem(){
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $items=$contents['item'];
    $quantitys=$contents['quantity'];
    $loc=$contents['loc'];
    $count=0;
    while($count<count($items)){
            $ia=new itemAccessor();
            $ia->moveStoreItem($loc, $items[$count], $quantitys[$count]);
            $count=$count+1;
    }
    echo 1;
}
function doGetInvItem(){
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $id=$contents['item'];
    $loc=$_GET['loc'];
    $ia=new itemAccessor();
    $result=$ia->getWareItem($id, $loc);
    echo json_encode($result, JSON_NUMERIC_CHECK);
}
function doGetWarehouse(){
try{
    $ia = new itemAccessor();
    $result=$ia->getWareItem($_GET['ware'], 1);
    $result=json_encode($result, JSON_NUMERIC_CHECK);
    echo $result;
}
catch (Exception $e){
    echo "ERROR " . $e->getMessage();
}
}
//if delete apply locked
function doGetLocInv(){
    try{
        $ia = new itemAccessor();
        $results=$ia->getLocationItems($_GET['local']);
        $results= json_encode($results, JSON_NUMERIC_CHECK);
        echo $results;
    } catch (Exception $ex) {
      echo "ERROR " . $ex->getMessage();
    }
}
function doGetSearch(){
    try{
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);
        $loc=$contents['location'];
        $ia = new itemAccessor();
        $results=$ia->getSearch($loc, $_GET['search']);
        $results= json_encode($results, JSON_NUMERIC_CHECK);
        echo $results;
    } catch (Exception $ex) {
      echo "ERROR " . $ex->getMessage();
    }
}
function doGetSupply(){
        try {
            $ur = new itemAccessor();
            $results = $ur->getAllItems();
            $final = json_encode($results, JSON_NUMERIC_CHECK);
            echo $final;
        } catch (Exception $e) {
            echo "ERROR " . $e->getMessage();
        }
}
function doUpdateItem()
{   try {
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new itemAccessor();
    $id=$contents['id'];
    $name = $contents['name'];
    $desc=$contents['desc'];
    $cat=$contents['cat'];
    $sku=$contents['sku'];
    $wei=$contents['weight'];
    $whole=$contents['whole'];
    $ret=$contents['ret'];
    $caseSize=$contents['caseSize'];
    $supp=$contents['supp'];
    $userPerson = new Item($id,$name,$sku,$desc,$cat,$whole, $ret, $wei,1, $supp, $caseSize, 1, 5);
    $success = $ua->updateItem($userPerson); 
    echo $success;
    }
catch (PDOException $e) {
    $success = false;
    echo $e->getMessage();
    } 
}

function doCreate(){
    $body = file_get_contents('php://input');
    $contents = json_decode($body, true);
    $ua = new itemAccessor();
    $name = $contents['name'];
    $desc=$contents['desc'];
    $cat=$contents['cat'];
    $sku=$contents['sku'];
    $wei=$contents['weight'];
    $whole=$contents['whole'];
    $ret=$contents['ret'];
    $caseSize=$contents['caseSize'];
    $supp=$contents['supp'];
try {
    $userPerson = new Item(0,$name,$sku,$desc,$cat,$whole, $ret, $wei,1, $supp, $caseSize, 1, 5);
    $success = $ua->insertItem($userPerson);
    echo $success;       
} catch (PDOException $e) {
    $success = true;
    echo $e->getMessage();
}
}
