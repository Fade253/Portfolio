<?php
session_start();?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <button id='backBtn'>Log Out</button>
        <div>User:<?php echo $_SESSION['user']?></div>
        <div>-----</div>
        <div id="windows">
            <a href="admin.php">Admin</a>
            <?php
            if($_SESSION['perm']=="Trucking / Delivery" || $_SESSION['perm']=='Administrator'){
             ?>
            <a href="acadia.php">Acadia</a>
            <?php
            }
            if($_SESSION['perm']=='Administrator'){?>
            <a href="items.php">Item Crud</a>
            <?php
            }
            if ($_SESSION['perm']=='Store Manager' || $_SESSION['perm']=='Administrator' || $_SESSION['perm']=='Trucking / Delivery'){
            ?>
            <a href="inventory.php">Store inventory</a>
            <a href="locations.php">Store Locations</a>
            <a href="onlineCheck.php">Current Online Orders</a>
            <a href="loss.php">loss/returns</a>
            <?php
            }
            if($_SESSION['perm']=='Warehouse Manager' || $_SESSION['perm']=='Warehouse Employee' || $_SESSION['perm']=='Administrator'){
            ?>
            <a href="Orders.php">Orders</a>
            <a href="SupplierOrder.php">Supplier Order</a>
            <?php }?>
            <a href="reports.php">reports</a>
            <a href="orderprocess.php">Process</a>
        </div>
        <p>This is the Dashboard, please select the relevant button to go
        to where you need to go for the purpose you need</p>
        <script src="js/login.js"></script>
    </body>
</html> 