<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/items.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="home">Home</button>
        <br>
        <button id="AddButton">Add Item</button>
        <button id="UpdateButton" disabled>Update Item</button>
        <div id="AddUpdatePanel">
            <input id="id">            
            <div>
                <div class="formLabel">Name</div><input id="name">
            </div>
            <div>
                <div class="formLabel">Category</div>
                <select id="category">
                    <option value="Sports Equipment">Sports Equipment</option>
                    <option value="Camping">Camping</option>
                    <option value="Footwear">Footwear</option>
                    <option value="Apparel">Apparel</option>
                    <option value="Fitness">Fitness</option>
                </select>
            </div>
            <div>
                <div class="formLabel">Description</div><input id="desc">
            </div>
            <div>
                <div class="formLabel">sku</div><input id="sku">
            </div>
            <div>
                <div class="formLabel">weight</div><input id="weight">
            </div>
            <div>
                <div class="formLabel">WholeSale</div><input id="whole">
            </div>
            <div>
                <div class="formLabel">Retail</div><input id="retail">
            </div>
            <div>
                <div class="formLabel">Case Size</div><input id="case" type="number">
            </div>
            <div>
                <div class="formLabel">Supplier</div>
                <select id="supplier">
                    <option value=10000>Reebok</option>
                    <option value=11000>Spalding</option>
                    <option value=11111>Burton</option>
                    <option value=22222>TaylorMade</option>
                    <option value=33333>New Balance</option>
                    <option value=44444>Nike</option>
                    <option value=55555>Northface</option>
                    <option value=66666>CCM</option>
                    <option value=77777>Bauer</option>
                    <option value=88888>Coleman</option>
                    <option value=99999>UnderArmor</option>
                </select>
            </div>
            <div>
                <button id="DoneButton">Done</button>
                <button id="CancelButton">Cancel</button>
            </div>
            </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>sku</th>
                <th>description</th>
                <th>category</th>
                <th>whole sale</th>
                <th>weight</th>
                <th>retail</th>
                <th>supplier</th>
                <th>Case Sizes</th>
            </tr>
        </table>
    </body>
</html>


