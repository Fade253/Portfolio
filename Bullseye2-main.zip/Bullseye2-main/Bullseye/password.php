<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>

    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <div id="loginScreen">
            <div><label for="name">New Password</label><input class="loginSpace" name="password" id="password"></div>
            <div><label for="password">New Password</label><input class="loginSpace" name = "password2" id="password2" type="password"></div>
            <button id ="confirm" class="loginPageButton">Change Password</button> 
        </div>
        <script src="js/login.js"></script>
    </body>
</html> 
