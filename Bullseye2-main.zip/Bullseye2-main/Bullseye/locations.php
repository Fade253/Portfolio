<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/locations.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="home">Home</button>
        <br>
        <button id="AddButton">Add Location</button>
        <button id="DeleteButton" disabled>Delete Location</button>
        <button id="UpdateButton" disabled>Update Location</button>
        <div id="AddUpdatePanel">
            <input id="id">            
            <div>
                <div class="formLabel">Name</div><input id="name">
            </div>
            <div>
                <div class="formLabel">Province</div>
                <select id="province">
                    <option value="AB">Alberta</option>
                    <option value="BC">British Columbia</option>
                    <option value="MB">Manitoba</option>
                    <option value="NB">New Brunswick</option>
                    <option value="NL">Newfoundland</option>
                    <option value="NS">Nova Scotia</option>
                    <option value="NT">Northwest Territorie</option>
                    <option value="NU">Nunavut</option>
                    <option value="ON">Ontario</option>
                    <option value="PE">Prince Edward Island</option>
                    <option value="QC">Quebec</option>
                    <option value="SK">Saskatchewan</option>
                    <option value="YT">Yukon</option>
                </select>
            </div>
            <div>
                <div class="formLabel">Address</div><input id="address">
            </div>
            <div>
                <div class="formLabel">City</div><input id="city">
            </div>
            <div>
                <div class="formLabel">Postal code</div><input id="post">
            </div>
            <div>
                <div class="formLabel">Phone</div><input id="phone" text="506">
            </div>
            <div>
                <div class="formLabel">Day</div><input id="dow">
            </div>
            <div>
                <div class="formLabel">Warehouse distance</div><input id="distance" type="number">
            </div>
            <div>
                <div class="formLabel">Site Type</div>
                <select id="type">
                    <option value="Warehouse">Warehouse</option>
                    <option value="Office">Office</option>
                    <option value="Truck">Truck</option>
                    <option value="Retail">Retail</option>
                </select>
            </div>
            <div>
                <div class="formLabel">Active?</div><input id="active" type="checkbox">
            </div>
            <div>
                <button id="DoneButton">Done</button>
                <button id="CancelButton">Cancel</button>
            </div>
            </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Province</th>
                <th>address</th>
                <th>city</th>
                <th>country</th>
                <th>postal code</th>
                <th>phone</th>
                <th>Type</th>
                <th>Day of week</th>
            </tr>
        </table>
    </body>
</html>

