<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <select id="locations">
            
        </select>
        <div>emergency?<input type="checkbox" id="emergency"></div>
        <button id="get">Get Items</button>
        <button id="confirm">Confirm items for order</button>
        <button id="research">Search</button>
        <button id="DoneButton">Done</button>
        <button id="ready">Order is Ready for Pickup</button>
        <button id='backBtn'>Log Out</button>
        <table>
                <th>ID</th>
                <th>To</th>
                <th>Status</th>
                <th>Ship Date</th>
                <th>Emergency</th>
        </table>
        <script src="js/order.js"></script>
    </body>
</html> 
