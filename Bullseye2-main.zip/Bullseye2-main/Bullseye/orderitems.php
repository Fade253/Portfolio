<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div><!-- comment -->
        <select id="locations">
            
        </select>
        <div>emergency?<input type="checkbox" id="emergency"></div>
        <button id="get">Get Items</button>
        <button id="DoneButton">Done</button>
        <button id="DateButton">Get Date</button>
        <div>getting the date is causing an issue when doing it in an order so it 
            is reccomended you push the get Date Button BEFORE you hit done</div>
        <div><div class='formLabel'>Search</div><input id='search' type='text'></div>
        <button id='backBtn'>Log Out</button>
        <a href="StoreOrder.php" id="orderLink">Check Saved order</a>
        <table>
            <th>item</th>
            <th>Name</th>
            <th>Wholesale cost</th>
            <th>Weight</th>
            <th>Quantity</th>
            <th>Case Size</th>
            <th>amount to order</th>
        </table>
        <script src="js/orderitems.js"></script>
    </body>
</html> 

