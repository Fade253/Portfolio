<?php
class Supplier implements JsonSerializable {
    private $id;
    private $name;
    private $address;
    private $city;
    private $province;
    private $contact;

    public function __construct($id, $username, $password, $first, $last, $email) {
        $this->id = $id;
        $this->name = $username;
        $this->address = $password;
        $this->city = $first;
        $this->province = $last;
        $this->contact = $email;
    }
    public function getID(){
        return $this->id;
    }
    public function getName() {
        return $this->name;
    }
    public function getAddress() {
        return $this->address;
    }
    public function getCity() {
        return $this->city;
    }public function getProvince() {
        return $this->province;
    }public function getContact() {
        return $this->contact;
    }
    public function jsonSerialize() {
        return get_object_vars($this);
    }
}

