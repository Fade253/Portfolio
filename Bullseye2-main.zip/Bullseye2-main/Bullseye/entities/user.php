<?php
class User implements JsonSerializable {
    private $id;
    private $username;
    private $password;
    private $first;
    private $last;
    private $email;
    private $active;
    private $locked;
    private $position;
    private $site;

    public function __construct( $id, $username, $password, $first, $last, $email, $active, $locked, $position, $site) {
        $this->id = $id;
        $this->username = $username;
        $this->password = $password;
        $this->first = $first;
        $this->last = $last;
        $this->email = $email;
        $this->active = $active;
        $this->locked = $locked;
        $this->position = $position;
        $this->site = $site;
    }
    public function getID(){
        return $this->id;
    }
    public function getUsername() {
        return $this->username;
    }
    public function getPassword() {
        return $this->password;
    }
    public function getFirstName() {
        return $this->first;
    }public function getLastName() {
        return $this->last;
    }public function getEmail() {
        return $this->email;
    }public function getActive() {
        return $this->active;
    }public function getlocked() {
        return $this->locked;
    }public function getPosition() {
        return $this->position;
    }public function getSite() {
        return $this->site;
    }
    public function jsonSerialize() {
        return get_object_vars($this);
    }
}
