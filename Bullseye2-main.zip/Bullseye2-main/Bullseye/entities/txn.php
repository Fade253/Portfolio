<?php
class txn implements JsonSerializable {
    private $id;
    private $to;
    private $from;
    private $status;
    private $ship;
    private $type;
    private $created;
    private $delivery;

    public function __construct($id, $to, $from, $status, $ship, $type, $created, $delivery) {
        $this->id = $id;
        $this->to = $to;
        $this->from=$from;
        $this->status = $status;
        $this->ship=$ship;
        $this->type = $type;
        $this->created=$created;
        $this->delivery = $delivery;
    }
    public function getID(){
        return $this->id;
    }
    public function getTo() {
        return $this->to;
    }
    public function getFrom() {
        return $this->from;
    } public function getStatus() {
        return $this->status;
    }
    public function getShipID(){
        return $this->ship;
    }
    public function getType() {
        return $this->type;
    }public function getCreationDate() {
        return $this->created;
    }public function getDelivery() {
        return $this->delivery;
    }
    public function jsonSerialize() {
        return get_object_vars($this);
    }
}