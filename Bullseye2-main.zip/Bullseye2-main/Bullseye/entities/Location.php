<?php
class Location implements JsonSerializable {
    private $id;
    private $name;
    private $province;
    private $address;
    private $city;
    private $country;
    private $postal;
    private $phone;
    private $day;
    private $distance;
    private $type;
    private $active;

    public function __construct($id, $name, $province, $address, $city, $country, $postal, $phone, $day, $distance, $type, $active) {
        $this->id = $id;
        $this->name = $name;
        $this->province=$province;
        $this->address = $address;
        $this->city=$city;
        $this->country=$country;
        $this->postal = $postal;
        $this->phone = $phone;
        $this->day = $day;
        $this->distance=$distance;
        $this->type = $type;
        $this->active= $active;
    }
    public function getID(){
        return $this->id;
    }
    public function getName() {
        return $this->name;
    }
    public function getAddress() {
        return $this->address;
    } public function getCity() {
        return $this->city;
    }
    public function getProvince(){
        return $this->province;
    }
    public function getPostal() {
        return $this->postal;
    }public function getPhone() {
        return $this->phone;
    }public function getDay() {
        return $this->day;
    }public function getDistance() {
        return $this->distance;
    }public function getType() {
        return $this->type;
    }
    public function getActive(){
        return $this->active;
    }
    public function jsonSerialize() {
        return get_object_vars($this);
    }
}
