<?php
class Report implements JsonSerializable {
    private $feild1;
    private $feild2;
    private $feild3;
    private $feild4;
    private $feild5;
    private $feild6;
    private $feild7;
    private $feild8;
    private $feild9;
    private $feild10;
    public function __construct($a, $b, $c, $d, $e, $f, $g, $h,$i, $j) {
        $this->feild1 = $a;
        $this->feild2 = $b;
        $this->feild3=$c;
        $this->feild4=$d;
        $this->feild5=$e;
        $this->feild6=$f;
        $this->feild7=$g;
        $this->feild8=$h;
        $this->feild9=$i;
        $this->feild10=$j;
    }
    public function get1(){
        return $this->feild1;
    }
    public function get2(){
        return $this->feild2;
    }
    public function get3() {
        return $this->feild3;
    }
    public function get4(){
        return $this->feild4;
    }
    public function get5(){
        return $this->feild5;
    }
    public function get6(){
        return $this->feild6;
    }
    public function get7(){
        return $this->feild7;
    }
    public function get8(){
        return $this->feild8;
    }
    public function get9() {
        return $this->feild9;
    }
    public function get10(){
        return $this->feild10;
    }
    public function jsonSerialize() {
        return get_object_vars($this);
    }
}
