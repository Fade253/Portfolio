<?php

class Item implements JsonSerializable {
    private int $id;
    private $name;
    private $sku;
    private $description;
    private String $category;
    private $wholecost;
    private $retail;
    private $weight;
    private $supplier;
    private $quantity;
    private $caseSize;
    private $active;
    private $location;
    private $reorder;
    public function __construct($id, $name, $sku, $desc, $cat, $whole, $ret, $weight,$quantity, $supp, $case, $location, $reorder) {
        $this->id = $id;
        $this->name = $name;
        $this->sku=$sku;
        $this->description=$desc;
        $this->category=$cat;
        $this->wholecost=$whole;
        $this->retail=$ret;
        $this->weight=$weight;
        $this->quantity=$quantity;
        $this->supplier=$supp;
        $this->caseSize=$case;
        $this->active=1;
        $this->location=$location;
        $this->reorder=$reorder;
    }
    public function getID(){
        return $this->id;
    }
    public function getSku(){
        return $this->sku;
    }
    public function getName() {
        return $this->name;
    }
    public function getDesc(){
        return $this->description;
    }
    public function getCase(){
        return $this->caseSize;
    }
    public function getCategory(){
        return $this->category;
    }
    public function getQuantity(){
        return $this->quantity;
    }
    public function getWhole(){
        return $this->wholecost;
    }
    public function getRetail() {
        return $this->retail;
    }
    public function getSupplier(){
        return $this->supplier;
    }
    public function getWeight(){
        return $this->weight;
    }
    public function getShelf(){
        return $this->location;
    }
    public function getThresh(){
        return $this->reorder;
    }
    public function jsonSerialize() {
        return get_object_vars($this);
    }
}

