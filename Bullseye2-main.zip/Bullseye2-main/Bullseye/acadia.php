<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/acadia.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="home">Home</button>
        <br>
        <button id="createOrder">Order</button>
        <button id='builditem'>show items</button>
        <button id="getDistance">Get Distance</button>
        <input id="site">
        <div id="AddUpdatePanel">
            <input id="id">            
            <div>
                <div class="formLabel">truck-sizes</div>
                <select>
                    <option value="Van">Van</option>
                    <option value="Small">Small</option>
                    <option value="Medium">Medium</option>
                    <option value="Heavy">Heavy</option>
                </select>
            </div>
            <div>
                <div class="formLabel">distance</div><input id="distance">
            </div>
            <div>
                <button id="getOrders">Get orders</button>
                <button id="DoneButton">Done</button>
                <button id="CancelButton">Cancel</button>
            </div>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <th>To</th>
                <th>From</th>
                <th>Status</th>
                <th>DeliveryID</th>
            </tr>
        </table>
    </body>
</html>

