<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/admin.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="GetButton">Show Employees</button>
        <br>
        <button id="AddButton">Add account</button>
        <button id="DeleteButton" disabled>Delete Account</button>
        <button id="UpdateButton" disabled>Update Account</button>
        <div id="AddUpdatePanel">
            <input id="id">
            <input id="user">
            <div>
                <div class="formLabel">First Name</div><input id="first">
            </div>
            <div>
                <div class="formLabel">Last Name</div><input id="last">
            </div>
            <div>
                <div class="formLabel">Password</div><input id="password">
            </div>
            <div>
                <div class="formLabel">Position</div>
                <select id="permission">
                    <option value="1">Regional Manager</option>
                    <option value="2">Financial Manager</option><!-- comment -->
                    <option value="3">Store Manager</option><!-- comment -->
                    <option value="4">Warehouse Manager</option>
                    <option value="5">Trucking/Delivery</option><!-- comment -->
                    <option value="6">Warehouse Employee</option><!--  -->
                    <option value="99999999">Admin</option>
                </select>
            </div>
            <div>
                <div class="formLabel">Site</div><select id="site">
                </select>
            </div>
            <div>
                
            </div>
            <div>
                <button id="DoneButton">Done</button>
                <button id="CancelButton">Cancel</button>
            </div>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Password</th>
                <th>First Name</th>
                <th>Last Name</th><!-- comment -->
                <th>Email</th><!-- comment -->
                <th>Active</th><!-- comment -->
                <th>position</th><!-- comment -->
                <th>Site</th>
            </tr>
        </table>

    </body>
</html>