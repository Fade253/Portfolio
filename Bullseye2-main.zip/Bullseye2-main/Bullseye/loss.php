<?php session_start();?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <button id='backBtn'>Log Out</button>
        <button id="get">Get items</button>
        <button id="DateButton">Get Date</button>
        <input id="locations" value=<?php echo $_SESSION['site']?>>
        <div id="AddUpdatePanel">
            <div>Notes:</div>
            <input type="text" id="notes">
            <select id="type">
                <option>Loss</option>
                <option>Damage</option>
                <option>Return</option>
            </select>
            <div>Return to shelf?:<input id="ret" type="checkbox"></div>
            <button id="DoneButton">Finish Return/Loss</button>
        </div>
        <input type="text" id="search">
        <table>
            <tr>
                <th>ID</th>
                <th>Item</th>
                <th>Retail</th>
                <th>Wholesale</th>
                <th>Quantity</th>
                <th>Case Size</th>
                <th>Problem Item</th>
            </tr>
        </table>
        <script src="js/login.js"></script>
        <script src="js/loss.js"></script>
    </body>
</html> 
