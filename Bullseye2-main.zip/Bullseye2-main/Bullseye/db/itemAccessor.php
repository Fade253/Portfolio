<?php
$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/Bullseye';
require_once 'DatabaseConnecter.php';
require_once ($projectRoot . '/entities/Item.php');
require_once ($projectRoot.'/entities/supplier.php');
require_once ($projectRoot. '/db/auditAccessor.php');
class itemAccessor {
    private $getByIDStatementString = "select * from item where id = :id";
    private $getSupplier="select * from supplier";
    private $removeinv="update inventory set quantity=quantity-:math where siteID=:site and itemID=:id";
    private $addtoinv="update inventory set quantity=quantity+:math where siteID=:site and itemID=:id";
    private $getSupplierItems="select item.*, inventory.* from item inner join inventory on item.itemID=inventory.itemID where inventory.siteID=1";
    private $moveOnlineItem="update inventory set quantity=quantity-:math where siteID=:loc and itemID=:id";
    private $getBackOrder="select * from txn where txnType='Back Order' ORDER by txnID DESC LIMIT 1";
    private $addBackOrder="insert into txnitems values (:id, :item, :quantity)";
    private $moveItem="update inventory set quantity=quantity - :math where siteID=1 and itemID=:id";
    private $moveItemToStore="update inventory set quantity=quantity+:math where siteID=:loc and itemID=:id";
    private $moveBay="insert into inventory values(:id, 2, :quantity, 'stock', 5)";
    private $moveTruck="delete from inventory where itemID=:id and siteID=9999";
    private $moveFromBay="delete from inventory where itemID=:id and siteID=2";
    private $orderremove="delete from txnitems where txnID=:id and itemID=:item";
    private $getByIDFromWareState="select item.*, inventory.* from item inner join inventory on inventory.itemID=item.itemID where inventory.siteID=1 and inventory.itemID=:id";
    private $getByTxnState="select item.*, txnitems.* from item inner join txnitems on item.itemID=txnitems.ItemID where txnitems.txnID=:id";
    private $getByLocationState="select item.*, inventory.* from item inner join inventory on inventory.itemID = item.itemID where inventory.siteID=:location";
    private $getBySearchState='select item.*, inventory.* from item inner join inventory on inventory.itemID = item.itemID where inventory.siteID=:location and name LIKE :wild';
    private $addEmployeeStatementString="insert into item values (null, :name, :sku, :desc, :cat, :wei, :whole, :ret, :supp, 1, ' ', :case)";
    private $updateUserStatementString="update item set name=:name, description=:desc, sku=:sku, category=:cat, weight=:wei, costPrice=:whole, retailPrice=:ret, caseSize=:case, supplierID=:supp where itemID=:id";
    private $deleteStatementString="update item set active=0 where itemID= :item";
    private $conn = NULL;
    private $bay = NULL;
    private $item=NULL;
    private $supp=NULL;
    private $suppItem=NULL;
    private $onmove=NULL;
    private $getBack=NULL;
    private $orderRem=NULL;
    private $getByIdFromWare=NULL;
    private $getBySearch=NULL;
    private $getByTxn=NULL;
    private $move = NULL;
    private $truckbay=NULL;
    private $bayTruck=NULL;
    private $storemove=NULL;
    private $getByLocationStatement=NULL;
    private $getByIDStatement = NULL;
    private $deleteStatement = NULL;
    private $insertStatement = NULL;
    private $updateStatement = NULL;
    // Constructor will throw exception if there is a problem with ConnectionManager,
    // or with the prepared statements.
    public function __construct() {
        $cm = new Connector();
        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->getByTxn = $this->conn->prepare($this->getByTxnState);
        if (is_null($this->getByTxn)) {
            throw new Exception("bad statement: '" . $this->getByTxnState . "'");
        }
        $this->move = $this->conn->prepare($this->moveItem);
        if (is_null($this->move)) {
            throw new Exception("bad statement: '" . $this->moveItem . "'");
        }
        $this->supp = $this->conn->prepare($this->getSupplier);
        if (is_null($this->supp)) {
            throw new Exception("bad statement: '" . $this->getSupplier . "'");
        }
        $this->suppItem = $this->conn->prepare($this->getSupplierItems);
        if (is_null($this->suppItem)) {
            throw new Exception("bad statement: '" . $this->getSupplierItems . "'");
        }
        $this->onmove = $this->conn->prepare($this->moveOnlineItem);
        if (is_null($this->onmove)) {
            throw new Exception("bad statement: '" . $this->moveOnlineItem . "'");
        }
        $this->truckbay = $this->conn->prepare($this->moveTruck);
        if (is_null($this->truckbay)) {
            throw new Exception("bad statement: '" . $this->moveTruck . "'");
        }
        $this->bayTruck = $this->conn->prepare($this->moveFromBay);
        if (is_null($this->bayTruck)) {
            throw new Exception("bad statement: '" . $this->moveFromBay . "'");
        }
        $this->storemove = $this->conn->prepare($this->moveItemToStore);
        if (is_null($this->storemove)) {
            throw new Exception("bad statement: '" . $this->moveItemToStore . "'");
        }
        $this->orderRem = $this->conn->prepare($this->orderremove);
        if (is_null($this->orderRem)) {
            throw new Exception("bad statement: '" . $this->orderremove . "'");
        }
        $this->getBack = $this->conn->prepare($this->getBackOrder);
        if (is_null($this->getBack)) {
            throw new Exception("bad statement: '" . $this->getBackOrder . "'");
        }
        $this->bay = $this->conn->prepare($this->moveBay);
        if (is_null($this->bay)) {
            throw new Exception("bad statement: '" . $this->moveBay . "'");
        }
        $this->getByIdFromWare = $this->conn->prepare($this->getByIDFromWareState);
        if (is_null($this->getByIdFromWare)) {
            throw new Exception("bad statement: '" . $this->getByIDFromWareState . "'");
        }
        $this->getBySearch = $this->conn->prepare($this->getBySearchState);
        if (is_null($this->getBySearch)) {
            throw new Exception("bad statement: '" . $this->getBySearchState . "'");
        }
        $this->getByIDStatement = $this->conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }
        $this->getByLocationStatement = $this->conn->prepare($this->getByLocationState);
        if (is_null($this->getByLocationState)) {
            throw new Exception("bad statement: '" . $this->getByLocationState . "'");
        }
        $this->deleteStatement = $this->conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("bad statement: '" . $this->deleteStatementString . "'");
        }
        $this->updateStatement = $this->conn->prepare($this->updateUserStatementString);
         if (is_null($this->updateStatement)) {
            throw new Exception("bad statement: '" . $this->updateUserStatementString . "'");
        }
        $this->insertStatement = $this->conn->prepare($this->addEmployeeStatementString);
        if (is_null($this->insertStatement)) {
            throw new Exception("bad statement: '" . $this->addEmployeeStatementString . "'");
        }

        //$this->updateStatement = $this->conn->prepare($this->updateStatementString);
        //if (is_null($this->updateStatement)) {
        //    throw new Exception("bad statement: '" . $this->updateStatementString . "'");
       //}
    }
    /**
     * Gets menu items by executing a SQL "select" statement. An empty array
     * is returned if there are no results, or if the query contains an error.
     * 
     * @param String $selectString a valid SQL "select" statement
     * @return array MenuItem objects
     */
    public function moveItem($item, $quantity){
        $this->move->bindParam(":math", $quantity);
        $this->move->bindParam(":id", $item);
        $this->move->execute();
        $this->bay->bindParam(":math", $quantity);
        $this->bay->bindParam(":id", $item);
        $this->bay->execute();
    }
    public function moveBayItem($loc, $item, $quantity){
        $this->storemove->bindParam(":math", $quantity);
        $this->storemove->bindParam(":id", $item);
        $this->storemove->bindParam(':loc', $loc);
        $this->storemove->execute();
        $this->bayTruck->bindParam(":id", $item);
        $this->bayTruck->execute();
    }
    public function moveStoreItem($loc, $item, $quantity){
        $this->storemove->bindParam(":math", $quantity);
        $this->storemove->bindParam(":id", $item);
        $this->storemove->bindParam(':loc', $loc);
        $this->storemove->execute();
        $this->truckbay->bindParam(":id", $item);
        $this->truckbay->execute();
    }
    public function moveOnlineItem($loc, $item, $quantity){
        $this->onmove->bindParam(":math", $quantity);
        $this->onmove->bindParam(":id", $item);
        $this->onmove->bindParam(':loc', $loc);
        $this->onmove->execute();
    }
    public function removeFromOrder($id, $item){
        $this->orderRem->bindParam(":id", $id);
        $this->orderRem->bindParam(":item", $item);
        $this->orderRem->execute();
    }
    public function addBackOrderItems($items, $quantity){
        $count = 0;
        try{
         $id=$this->getIDFromBack();
        while($count < count($items)){
            $this->addBack=$this->conn->prepare($this->addBackOrder);
            $this->addBack->bindParam(":id", $id);
            $this->addBack->bindParam(":item", $items[$count]);
            $this->addBack->bindParam(":quantity", $quantity[$count]);
            $this->addBack->execute();
            $count++;
        }
        $a=new auditAccessor();
        $a->Audit('Back Order', $_SESSION['id'], 'Backorder created for store', $_SESSION['site']);
        return 1;   
        } catch (Exception $ex) {
            return "ERROR ".$ex->getMessage();
        }
    }
    public function getSuppliers(){
        $result=[];
        try{
        $this->supp->execute();
        $dbresults=$this->supp->fetchAll(PDO::FETCH_ASSOC);
        foreach($dbresults as $s){
        $id=$s['supplierID'];
        $name=$s['name'];
        $address=$s['address1'];
        $city=$s['city'];
        $province=$s['province'];
        $contact=$s['contact'];
        $obj = new Supplier($id, $name, $address, $city, $province, $contact);
        array_push($result, $obj);
    }
    return $result;
        }
        catch(PDOException $ex){
            return $ex->getMessage();
        }
    }
    private function getIDFromBack(){
        $id=0;
        $this->getBack->execute();
        $dbres=$this->getBack->fetchAll(PDO::FETCH_ASSOC);
        foreach($dbres as $r){
            $id=$r['txnID'];
        }
        return $id;
    }
    private function getItemsByQuery($selectString) {
        $result = [];
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $sku = $r['sku'];
                $desc=$r['description'];
                $cat = $r['category'];
                $weight=$r['weight'];
                $whole=$r['costPrice'];
                $retail=$r['retailPrice'];
                $supp=$r['supplierID'];
                $quant=1;
                $size=$r['caseSize'];
                $obj = new Item($id, $name, $sku, $desc, $cat, $weight, $whole, $retail, $quant, $supp, $size, 1, 1);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }

        return $result;
    }
    public function getTxnItems($id){
        $result=[];
        try{
            $stmt=$this->getByTxn;
            $stmt->bindParam(":id", $id);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $sku = $r['sku'];
                $desc =$r['description'];
                $cat =$r['category'];
                $cost=$r['costPrice'];
                $retail=$r['retailPrice'];
                $weight=$r['weight'];
                $size=$r['quantity'];
                $supplier=$r['supplierID'];
                $casesize=$r['caseSize'];
                $obj = new Item($id, $name, $sku, $desc, $cat,  $cost, $retail, $weight, $size, $supplier, $casesize, 'e', 0);
                array_push($result, $obj);
            }
        } catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }
        return $result;
        }
        public function getSupplierItems(){
        $result=[];
        try{
            $this->suppItem->execute();
            $dbresults = $this->suppItem->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $sku = $r['sku'];
                $desc =$r['description'];
                $cat =$r['category'];
                $cost=$r['costPrice'];
                $retail=$r['retailPrice'];
                $weight=$r['weight'];
                $supplier=$r['supplierID'];
                $casesize=$r['caseSize'];
                $obj = new Item($id, $name, $sku, $desc, $cat,  $cost, $retail, $weight, 0, $supplier, $casesize, 'e', 0);
                array_push($result, $obj);
            }
        } catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($this->suppItem)) {
                $this->suppItem->closeCursor();
            }
        }
        return $result;
        }
    public function getWareItem($id, $loc){
        $result=[];
        try{
            $stmt=$this->getByLocationStatement;
            $stmt->bindParam(":location", $loc);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach($dbresults as $r){
                if($r['itemID']==$id){
                    array_push($result, $r['quantity']);
                }
            }
         return $result;
        }
        catch(Exception $e){
            return $e->getMessage();
        }
    }
    public function getLocationItems($location){
        $result = [];
        try {
            $stmt=$this->getByLocationStatement;
            $stmt->bindParam(":location", $location);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $sku = $r['sku'];
                $desc =$r['description'];
                $cat =$r['category'];
                $cost=$r['costPrice'];
                $retail=$r['retailPrice'];
                $weight=$r['weight'];
                $size=$r['quantity'];
                $supplier=$r['supplierID'];
                $casesize=$r['caseSize'];
                $reorder=$r['reorderThreshold'];
                $location=$r['itemLocation'];
                $obj = new Item($id, $name, $sku, $desc, $cat,  $cost, $retail, $weight, $size, $supplier, $casesize, $location, $reorder);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }
        return $result;
    }
    public function getSearch($location, $search){
        $result = [];
        try {
            $stmt=$this->getBySearch;
            $arg="%".$search."%";
            $stmt->bindParam(":location", $location);
            $stmt->bindParam(":wild", $arg);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $sku = $r['sku'];
                $desc =$r['description'];
                $cat =$r['category'];
                $cost=$r['costPrice'];
                $retail=$r['retailPrice'];
                $weight=$r['weight'];
                $size=$r['quantity'];
                $supplier=$r['supplierID'];
                $casesize=$r['caseSize'];
                $reorder=$r['reorderThreshold'];
                $location=$r['itemLocation'];
                $obj = new Item($id, $name, $sku, $desc, $cat,  $cost, $retail, $weight, $size, $supplier, $casesize, $location, $reorder);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }
        return $result;
    }
    public function getAllItems() {
        return $this->getItemsByQuery("select * from item");
    }
    public function insertItem($new) {
        $success=0;
        $name = $new->getName();
        $desc = $new->getDesc();
        $sku = $new->getSku();
        $cat = $new->getCategory();
        $supp = $new->getSupplier();
        $whole=$new->getWhole();
        $ret=$new->getRetail();        
        $wei=$new->getWeight();
        $case=$new->getCase();
        try {
            //$this->insertStatement->bindParam(":itemid", 1016);
            $this->insertStatement->bindParam(":name", $name);
            $this->insertStatement->bindParam(":desc", $desc);
            $this->insertStatement->bindParam(":sku", $sku);
            $this->insertStatement->bindParam(":cat", $cat);
            $this->insertStatement->bindParam(":supp", $supp);
            $this->insertStatement->bindParam(":whole", $whole);
            $this->insertStatement->bindParam(":ret", $ret);
            $this->insertStatement->bindParam(":wei", $wei);
            $this->insertStatement->bindParam(":case", $case);
            $this->insertStatement->execute();// this doesn't mean what you think it means
            $success=1;
            return $success;
        }
        catch (PDOException $e) {
            return $cat;
        }
        finally {
            if (!is_null($this->insertStatement)) {
                $this->insertStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'added new item', $_SESSION['site']);
            }
        }
    }
    public function updateItem($new){
        $id=$new->getID();
        $name = $new->getName();
        $desc = $new->getDesc();
        $sku = $new->getSku();
        $cat = $new->getCategory();
        $supp = $new->getSupplier();
        $whole=$new->getWhole();
        $ret=$new->getRetail();        
        $wei=$new->getWeight();
        $case=$new->getCase();
        try {
            $this->updateStatement->bindParam(":id", $id);
            $this->updateStatement->bindParam(":name", $name);
            $this->updateStatement->bindParam(":desc", $desc);
            $this->updateStatement->bindParam(":sku", $sku);
            $this->updateStatement->bindParam(":cat", $cat);
            $this->updateStatement->bindParam(":whole", $whole);
            $this->updateStatement->bindParam(":ret", $ret);
            $this->updateStatement->bindParam(":wei", $wei);
            $this->updateStatement->bindParam(":supp", $supp);
            $this->updateStatement->bindParam(":case", $case);
            $this->updateStatement->execute();// this doesn't mean what you think it means
            $success=1;
        }
        catch (PDOException $e) {
            $success=$e->getMessage();
        }
        finally {
            if (!is_null($this->updateStatement)) {
                $this->updateStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Correction', $_SESSION['id'], 'Corrected Item', $_SESSION['site']);
            }
            return $success;
        }
    }
    public function applyInventoryChange($items, $quantity, $bool, $site){
        try{
        $count=0;
        $this->getrecent->execute();
        $result=$this->getrecent->fetchAll(PDO::FETCH_ASSOC);
        $id=0;
        foreach($result as $r)
        {
         $id=$r['txnID'];   
        }
        $item = array_values($items);
        $quant = array_values($quantity);
        while ($count < count($items)){
            if($bool){
           $this->item = $this->conn->prepare($this->addtoinv);
           $this->item->bindParam(":site", $site);
           $this->item->bindParam(":id", $item[$count]);
           $this->item->bindParam(":math", $quant[$count]);
           $this->item->execute();
           $count+=1;
            }
            else{
           $this->item = $this->conn->prepare($this->removeinv);
           $this->item->bindParam(":site", $site);
           $this->item->bindParam(":id", $item[$count]);
           $this->item->bindParam(":math", $quant[$count]);
           $this->item->execute();
           $count+=1;
            }
    }
          return 1;
    }
    catch(PDOException $ex){
        return $ex->getMessage();
    }
}
}