<?php
$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/Bullseye';
require_once 'DatabaseConnecter.php';
require_once ($projectRoot . '/db/LocationAccessor.php');
require_once ($projectRoot. '/db/auditAccessor.php');
require_once ($projectRoot . '/entities/User.php');
require_once ($projectRoot . '/entities/User.php');

class UserAccessor {
    private $getByIDStatementString = "select * from employee where username = :user";
    private $getByEmailStatementString="select * from employee where email = :email";
    private $addEmployeeStatementString="insert into employee values (null, :user, :password, :first, :last, :email, :active, :locked, :position, :site)";
    private $deleteStatementString = "update employee set locked=1, active=0 where username = :user";
    private $updatePasswordStatementString = "update employee set password=:pass where email=:email";
    private $updateUserStatementString="update employee set password=:pass, firstName=:first, lastName=:last, email=:email, positionID=:position, siteID=:site where employeeID=:id";
    private $permissionString = "select permissionLevel from posn where positionID = :id";
    private $auditchange="insert into txnaudit values (null, null, 'Login', 'Changed Password', :date, :site, 1, :employee, null)";
    private $auditlogin="insert into txnaudit values (null, null, 'Login', 'logged-in', :date, :site, 1, :employee, null)";
    private $auditout="insert into txnaudit values (null, null, 'Logout', 'logged-out', :date, :site, 1, :employee, null)";
    private $auditadd="insert into txnaudit values (null, null, 'Correction', 'Added user', :date, 3, 1, :employee, null)";
    private $auditupdate="insert into txnaudit values (null, null, 'Correction', 'updated user', :date, 3, 1, :employee, null)";
    private $auditdelete="insert into txnaudit values (null, null, 'Correction', 'user deactivated', :date, :site, 1, :employee, null)";
    private $conn = NULL;
    private $auditstate = NULL;
    private $auditlogout = NULL;
    private $auditpass=NULL;
    private $auditnew=NULL;
    private $auditupp=NULL;
    private $auditdel=NULL;
    private $getPosition=NULL;
    private $getByEmailStatement=NULL;
    private $getByIDStatement = NULL;
    private $deleteStatement = NULL;
    private $insertStatement = NULL;
    private $updatePasswordStatement=NULL;
    private $updateStatement = NULL;
    // Constructor will throw exception if there is a problem with ConnectionManager,
    // or with the prepared statements.
    public function __construct() {
        $cm = new Connector();
        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->getByIDStatement = $this->conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }
        $this->getPosition = $this->conn->prepare($this->permissionString);
        if (is_null($this->getPosition)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }
      $this->auditstate = $this->conn->prepare($this->auditlogin);
        if (is_null($this->auditstate)) {
            throw new Exception("bad statement: '" . $this->auditlogin . "'");
        }
        $this->auditpass = $this->conn->prepare($this->auditchange);
        if (is_null($this->auditpass)) {
            throw new Exception("bad statement: '" . $this->auditchange . "'");
        }
      $this->auditlogout = $this->conn->prepare($this->auditout);
        if (is_null($this->auditlogout)) {
            throw new Exception("bad statement: '" . $this->auditout . "'");
        }
        $this->auditnew = $this->conn->prepare($this->auditadd);
        if (is_null($this->auditnew)) {
            throw new Exception("bad statement: '" . $this->auditadd . "'");
        }
        $this->auditdel = $this->conn->prepare($this->auditdelete);
        if (is_null($this->auditdel)) {
            throw new Exception("bad statement: '" . $this->auditdelete . "'");
        }
        $this->auditupp = $this->conn->prepare($this->auditupdate);
        if (is_null($this->auditupp)) {
            throw new Exception("bad statement: '" . $this->auditupdate . "'");
        }
        $this->deleteStatement = $this->conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("bad statement: '" . $this->deleteStatementString . "'");
        }
        $this->getByEmailStatement = $this->conn->prepare($this->getByEmailStatementString);
         if (is_null($this->getByEmailStatement)) {
            throw new Exception("bad statement: '" . $this->getByEmailStatementString . "'");
        }
        $this->updatePasswordStatement = $this->conn->prepare($this->updatePasswordStatementString);
         if (is_null($this->updatePasswordStatement)) {
            throw new Exception("bad statement: '" . $this->updatePasswordStatementString . "'");
        }
        $this->updateStatement = $this->conn->prepare($this->updateUserStatementString);
         if (is_null($this->updateStatement)) {
            throw new Exception("bad statement: '" . $this->updateUserStatementString . "'");
        }
        $this->insertStatement = $this->conn->prepare($this->addEmployeeStatementString);
        if (is_null($this->insertStatement)) {
            throw new Exception("bad statement: '" . $this->addEmployeeStatementString . "'");
        }
        //$this->updateStatement = $this->conn->prepare($this->updateStatementString);
        //if (is_null($this->updateStatement)) {
        //    throw new Exception("bad statement: '" . $this->updateStatementString . "'");
       //}
    }
    /**
     * Gets menu items by executing a SQL "select" statement. An empty array
     * is returned if there are no results, or if the query contains an error.
     * 
     * @param String $selectString a valid SQL "select" statement
     * @return array MenuItem objects
     */
    private function getUsersByQuery($selectString) {
        $result = [];
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['employeeID'];
                $user = $r['username'];
                $pass = $r['password'];
                $firstname=$r['firstName'];
                $lastname=$r['lastName'];
                $email=$r['email'];
                $active=$r['active'];
                $locked=$r['locked'];
                $positionID=$r['positionID'];
                $siteID=$r['siteID'];              
                $obj = new User($id, $user, $pass, $firstname, $lastname, $email, $active, $locked, $positionID, $siteID);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }
        return $result;
    }
    /**
     * Gets all menu items.
     * 
     * @return array MenuItem objects, possibly empty
     */
    public function getAllUsers() {
        return $this->getUsersByQuery("select * from employee");
    }
    /**
     * Gets the menu item with the specified ID.
     * 
     * @param Integer $id the ID of the item to retrieve 
     * @return the MenuItem object with the specified ID, or NULL if not found
     */
    public function Logout($user){
        try {
            $this->getByIDStatement->bindParam(":user", $user);
            $this->getByIDStatement->execute();
            $dbresults = $this->getByIDStatement->fetch(PDO::FETCH_ASSOC); // not fetchAll
                $id=$dbresults['employeeID'];
                $siteID=$dbresults['siteID'];
                $a=new auditAccessor();
                $a->Audit('Logout', $id, 'logged out', $siteID);
    }
        catch(Exception $e){
            return $e->getMessage();
        }
        return 1;
    }
    public function getUserByUsername($user, $date) {
        $result = [];
        try {
            $this->getByIDStatement->bindParam(":user", $user);
            $this->getByIDStatement->execute();
            $dbresults = $this->getByIDStatement->fetch(PDO::FETCH_ASSOC); // not fetchAll
            if ($dbresults) {
                $id = $dbresults['employeeID'];
                $user = $dbresults['username'];
                $pass = $dbresults['password'];
                $firstname=$dbresults['firstName'];
                $lastname=$dbresults['lastName'];
                $email=$dbresults['email'];
                $active=$dbresults['active'];
                $locked=$dbresults['locked'];
                $positionID=$dbresults['positionID'];
                $siteID=$dbresults['siteID'];
                $this->getPosition->bindParam(":id", $positionID);
                $this->getPosition->execute();
                $result = $this->getPosition->fetch(PDO::FETCH_ASSOC);
                $_SESSION['perm']=$result['permissionLevel'];
                $_SESSION['user']=$user;
                $_SESSION['id']=$id;
                $_SESSION['site']=$dbresults['siteID'];
                $usern = new User($id, $user, $pass, $firstname, $lastname, $email, $active, $locked, $positionID, $siteID);
                array_push($result, $usern);
            }
        }
        catch (Exception $e) {
            return $e->getMessage();
        }
        finally {
            if (!is_null($this->getByIDStatement)) {
                $this->getByIDStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Login', $_SESSION['id'], 'Logged In', $siteID);
            }
        }
        return $usern;
    }
public function getUserByEmail($email) {
        try {
            $this->getByEmailStatement->bindParam(":email", $email);
            $this->getByEmailStatement->execute();
            $dbresults = $this->getByEmailStatement->fetch(PDO::FETCH_ASSOC); // not fetchAll
            if ($dbresults) {
                $id = $dbresults['employeeID'];
                $user = $dbresults['username'];
                $pass = $dbresults['password'];
                $firstname=$dbresults['firstName'];
                $lastname=$dbresults['lastName'];
                $email=$dbresults['email'];
                $active=$dbresults['active'];
                $locked=$dbresults['locked'];
                $positionID=$dbresults['positionID'];
                $siteID=$dbresults['siteID'];
                $usern = new User($id, $user, $pass, $firstname, $lastname, $email, $active, $locked, $positionID, $siteID);
            }
        }
        catch (Exception $e) {
            $result = NULL;
        }
        finally {
            if (!is_null($this->getByIDStatement)) {
                $this->getByEmailStatement->closeCursor();
            }
        }
        return $usern;
    }
    /**
     * Deletes a menu item.
     * @param MenuItem $item an object whose ID is EQUAL TO the ID of the item to delete
     * @return boolean indicates whether the item was deleted
     */
    public function deleteUser($item, $date) {
        $success = false;
        $useID = $item->getUsername(); // only the ID is needed
        try {
            $this->deleteStatement->bindParam(":user", $useID);
            $success = $this->deleteStatement->execute(); // this doesn't mean what you think it means
            $rc = $this->deleteStatement->rowCount();
        }
        catch (PDOException $e) {
            $success = false;
        }
        finally {
            if (!is_null($this->deleteStatement)) {
                $this->deleteStatement->closeCursor();
                $site=3;
                $admin=1;
                $a=new auditAccessor();
                $a->Audit('Correction', $admin, 'Deleted User', $site);
            }
            return $success;
        }
    }

    /**
     * Inserts a menu item into the database.
     * 
     * @param MenuItem $item an object of type MenuItem
     * @return boolean indicates if the item was inserted
     */
    public function insertUser($new, $date) {
        $success = false;
//:user, :password, :first, :last, :email, :active, :locked, :position, :site
        $username = $new->getUsername();
        $pass = $new->getPassword();
        $first = $new->getFirstName();
        $last = $new->getLastName();
        $email = $new->getEmail();
        $active=$new->getActive();
        $lock=0;        
        $site=$new->getSite();
        $position=$new->getPosition();
        try {
            //$this->insertStatement->bindParam(":empid", 1016);
            $this->insertStatement->bindParam(":user", $username);
            $this->insertStatement->bindParam(":password", $pass);
            $this->insertStatement->bindParam(":first", $first);
            $this->insertStatement->bindParam(":last", $last);
            $this->insertStatement->bindParam(":email", $email);
            $this->insertStatement->bindParam(":active", $active);
            $this->insertStatement->bindParam(":locked", $lock);
            $this->insertStatement->bindParam(":site", $site);
            $this->insertStatement->bindParam(":position", $position);
            $success = $this->insertStatement->execute();// this doesn't mean what you think it means
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
        finally {
            if (!is_null($this->insertStatement)) {
                $this->insertStatement->closeCursor();
                $id=1;
                $a=new auditAccessor();
                $a->Audit('Correction', $id, 'Added User', $site);
            }
            return $success;
        }
    }

    /**
     * Updates a menu item in the database.
     * 
     * @param MenuItem $item an object of type MenuItem, the new values to replace the database's current values
     * @return boolean indicates if the item was updated
     */
    public function updateUser($new, $date) {
        $id=$new->getID();
        $pass = $new->getPassword();
        $first = $new->getFirstName();
        $last = $new->getLastName();
        $email = $new->getEmail();
        $site=$new->getSite();
        $position=$new->getPosition();
        try {
            $this->updateStatement->bindParam(":id", $id);
            $this->updateStatement->bindParam(":pass", $pass);
            $this->updateStatement->bindParam(":first", $first);
            $this->updateStatement->bindParam(":last", $last);
            $this->updateStatement->bindParam(":email", $email);
            $this->updateStatement->bindParam(":site", $site);
            $this->updateStatement->bindParam(":position", $position);
            $success = $this->updateStatement->execute();
        }
        catch (PDOException $e) {
            $success=false;
        }
        finally {
            if (!is_null($this->updateStatement)) {
                $this->updateStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Correction', $id, 'Updated User', $site);
            }
            return $success;
        }
    }
    public function changepassword($newpass, $date){
        $success = false;
        $emp= $this->getUserByEmail($_SESSION['email']);
        $id=$emp->getID();
        $site=$emp->getSite();
        $this->updatePasswordStatement->bindParam(":pass", $newpass);
        $this->updatePasswordStatement->bindParam(":email", $_SESSION['email']);
        $success = $this->updatePasswordStatement->execute();
        $a=new auditAccessor();
        $a->Audit('Login', $id, 'PasswordChanged', $site);
        return $success;
    }
}
