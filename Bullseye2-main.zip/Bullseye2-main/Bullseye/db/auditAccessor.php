<?php

class auditAccessor {
    private $auditGeneric="insert into txnaudit values (null, null, :type, :desc, CURDATE(), :site, 1, :employee, null)";
    private $conn = NULL;
    private $auditgen=NULL;
     public function __construct() {
        $cm = new Connector();
        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->auditgen = $this->conn->prepare($this->auditGeneric);
        if (is_null($this->auditgen)) {
            throw new Exception("bad statement: '" . $this->auditGeneric . "'");
        }
     }
     function Audit($type, $user, $desc, $site){
         $this->auditgen->bindParam(":type", $type);
         $this->auditgen->bindParam(":desc", $desc);
         $this->auditgen->bindParam(":site", $site);
         $this->auditgen->bindParam(":employee", $user);
         $this->auditgen->execute();
     }
}
