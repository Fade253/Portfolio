<?php
$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/Bullseye';
require_once 'DatabaseConnecter.php';
require_once ($projectRoot. '/db/auditAccessor.php');
require_once ($projectRoot . '/entities/order.php');
require_once ($projectRoot. '/entities/Item.php');
class orderAccessor {
    private $getByIDStatementString = "select * from txn where txnID = :id";
    private $onlineOrderState="select * from txn where txnType='Curbside' and siteIDFrom=:loc";
    private $onlineOrdState="select * from txn where notes LIKE :name";
    private $supplierOrder="insert into txn values(null, 1, 3, 'NEW', :ship, 'Supplier Order', null, CURDATE(), null, 0, '')";
    private $getBackOrderTxn="select * from txn where txnType = 'BACKORDER' and status != 'CLOSED'";
    private $makeBackOrder="insert into txn values (null, :site, 1, 'BACKORDER', CURDATE(), 'Back Order', null, CURDATE(), null, false, '')";
    private $processStatus="update txn set status='PROCESSING' where txnID=:id";
    private $readyStatus="update txn set status='READY' where txnID=:id";
    private $submitStatus="update txn set status='SUBMITTED' where txnID=:id";
    private $getOrderItemsStr="select item.*, txnitems.* from item inner join txnitems on txnitems.ItemID = item.itemID where txnitems.txnID=:id";
    private $transStatement="insert into txn values (null, :to, 1, 'NEW', :ship, 'Store Order', null, CURDATE(), null, :emergency, '')";
    private $onlineStatement="insert into txn values (null, 11, :to, 'PROCESSING', CURDATE(), 'Curbside', null, CURDATE(), null, :emergency, :note)";
    private $checktranstate="select * from txn where siteIDto=:site and txnType='Store Order'";
    private $updateUserStatementString="update txn set name=:name, provinceID=:province, address=:address, city=:city, postalCode=:postal, phone=:phone, dayOfWeek=:day, siteType=:type, active=:active where siteID=:id";
    private $deliverstr="insert into delivery values (null, :distance, :size, null)";
    private $pic ="update txn set deliveryID=(select deliveryID from delivery where deliveryID=LAST_INSERT_ID()) where txnID= :id";
    private $deliverystr="update txn set status='DELIVERED' where txnID=:id";
    private $closeStatementString="update txn set status='CLOSED' where txnID= :id";
    private $transstr="update txn set status='IN TRANSIT' where txnID=:id";
    private $cancelstr="update txn set status='CANCELLED'  where txnID=:id";
    private $itemstr="insert into txnitems values(:txn, :id, :quantity)";
    private $getrecentstr="select * from txn ORDER by txnID DESC LIMIT 1";
    private $opper="insert into txn values (null, :to, 3, 'REJECTED', CURDATE(), :type, null, CURDATE(), null, 0, :note)";
    private $opp="select * from txn where txntype='Loss' and txntype='Damage' and txntype='Return'";
    #private $auditstr='insert into txnaudit values(null, :id, "Store Order", )';
    private $trans=NULL;
    private $op=NULL;
    private $oppe=NULL;
    private $online=NULL;
    private $makeBack=NULL;
    private $backcheck=NULL;
    private $item=NULL;
    private $suppor=NULL;
    private $submit=NULL;
    private $process=NULL;
    private $ready = NULL;
    private $onlineOrder=NULL;
    private $onlineOrd=NULL;
    private $getBackOrder=NULL;
    private $getrecent=NULL;
    private $getOrderItems=NULL;
    private $checktrans=NULL;
    private $cancel=NULL;
    private $conn = NULL;
    private $pickupStatement=NULL;
    private $deliverState=NULL;
    private $DeliveryState=NULL;
    private $getByIDStatement = NULL;
    private $closeStatement=NULL;
    #private $insertStatement = NULL;
    private $updateStatement = NULL;
    // Constructor will throw exception if there is a problem with ConnectionManager,
    // or with the prepared statements.
    public function __construct() {
        $cm = new Connector();

        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->pickupStatement = $this->conn->prepare($this->pic);
        if (is_null($this->pickupStatement)) {
            throw new Exception("bad statement: '" . $this->pic . "'");
        }
        $this->trans = $this->conn->prepare($this->transStatement);
        if (is_null($this->trans)) {
            throw new Exception("bad statement: '" . $this->transStatement . "'");
        }
        $this->op = $this->conn->prepare($this->opp);
        if (is_null($this->op)) {
            throw new Exception("bad statement: '" . $this->opp . "'");
        }
        $this->oppe = $this->conn->prepare($this->opper);
        if (is_null($this->oppe)) {
            throw new Exception("bad statement: '" . $this->opper . "'");
        }
        $this->suppor = $this->conn->prepare($this->supplierOrder);
        if (is_null($this->suppor)) {
            throw new Exception("bad statement: '" . $this->supplierOrder . "'");
        }
        $this->onlineOrder = $this->conn->prepare($this->onlineOrderState);
        if (is_null($this->onlineOrder)) {
            throw new Exception("bad statement: '" . $this->onlineOrderState . "'");
        }
        $this->onlineOrd = $this->conn->prepare($this->onlineOrdState);
        if (is_null($this->onlineOrd)) {
            throw new Exception("bad statement: '" . $this->onlineOrdState . "'");
        }
        $this->online = $this->conn->prepare($this->onlineStatement);
        if (is_null($this->online)) {
            throw new Exception("bad statement: '" . $this->onlineStatement . "'");
        }
        $this->submit = $this->conn->prepare($this->submitStatus);
        if (is_null($this->submit)) {
            throw new Exception("bad statement: '" . $this->submitStatus . "'");
        }
        $this->makeBack = $this->conn->prepare($this->makeBackOrder);
        if (is_null($this->makeBack)) {
            throw new Exception("bad statement: '" . $this->makeBackOrder . "'");
        }
        $this->backcheck = $this->conn->prepare($this->transStatement);
        if (is_null($this->trans)) {
            throw new Exception("bad statement: '" . $this->transStatement . "'");
        }
        $this->ready = $this->conn->prepare($this->readyStatus);
        if (is_null($this->ready)) {
            throw new Exception("bad statement: '" . $this->readyStatus . "'");
        }
        $this->process = $this->conn->prepare($this->processStatus);
        if (is_null($this->process)) {
            throw new Exception("bad statement: '" . $this->processStatus . "'");
        }
        $this->getBackOrder = $this->conn->prepare($this->getBackOrderTxn);
        if (is_null($this->getBackOrder)) {
            throw new Exception("bad statement: '" . $this->getBackOrderTxn . "'");
        }
        $this->getrecent = $this->conn->prepare($this->getrecentstr);
        if (is_null($this->getrecent)) {
            throw new Exception("bad statement: '" . $this->getrecentstr . "'");
        }
        $this->checktrans = $this->conn->prepare($this->checktranstate);
        if (is_null($this->checktrans)) {
            throw new Exception("bad statement: '" . $this->checktranstate . "'");
        }
        $this->getOrderItems = $this->conn->prepare($this->getOrderItemsStr);
        if (is_null($this->getOrderItemsStr)) {
            throw new Exception("bad statement: '" . $this->getOrderItemsStr . "'");
        }
        $this->transStatement = $this->conn->prepare($this->transstr);
        if (is_null($this->transstr)) {
            throw new Exception("bad statement: '" . $this->transstr . "'");
        }
        $this->deliverState = $this->conn->prepare($this->deliverstr);
        if (is_null($this->deliverState)) {
           throw new Exception("bad statement: '" . $this->deliverstr . "'");
        }
        $this->DeliveryState = $this->conn->prepare($this->deliverystr);
        if (is_null($this->DeliveryState)) {
           throw new Exception("bad statement: '" . $this->deliverystr . "'");
        }
        $this->getByIDStatement = $this->conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
           throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }

        $this->cancel = $this->conn->prepare($this->cancelstr);
        if (is_null($this->cancel)) {
            throw new Exception("bad statement: '" . $this->cancelstr . "'");
        }
        $this->closeStatement = $this->conn->prepare($this->closeStatementString);
        if (is_null($this->closeStatement)) {
            throw new Exception("bad statement: '" . $this->closeStatementString . "'");
        }
        $this->updateStatement = $this->conn->prepare($this->updateUserStatementString);
         if (is_null($this->updateStatement)) {
            throw new Exception("bad statement: '" . $this->updateUserStatementString . "'");
        }
        //$this->updateStatement = $this->conn->prepare($this->updateStatementString);
        //if (is_null($this->updateStatement)) {
        //    throw new Exception("bad statement: '" . $this->updateStatementString . "'");
       //}
    }
    /**
     * Gets menu items by executing a SQL "select" statement. An empty array
     * is returned if there are no results, or if the query contains an error.
     * 
     * @param String $selectString a valid SQL "select" statement
     * @return array MenuItem objects
     */
    public function SupplierOrder($ship){
        $success=false;
        try{
            $this->suppor->bindParam(":ship", $ship);
            $this->suppor->execute();
            $success=true;
            $a=new auditAccessor();
                $a->Audit('Supplier Order', $_SESSION['id'], 'Supplier Order Created', $_SESSION['site']);
            return $success;
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
    }
    public function backOrder($id, $items, $quantitys){
        $ia=new itemAccessor();
        $site=$this->getSiteForBackOrder($id);
        if($this->checkBackorder()==0){
            $this->makeBack->bindParam(":site", $site);
            $this->makeBack->execute();
            $success=$ia->addBackOrderItems($items, $quantitys);
            return $success;
        }
        else{
            $success=$ia->addBackOrderItems($items, $quantitys);
            return $success;
        }
    }
    private function checkBackorder(){
        $this->getBackOrder->execute();
        return $this->getBackOrder->rowCount();
    }
    private function getSiteForBackOrder($id){
        $site=null;
        $this->getByIDStatement->bindParam(":id", $id);
        $this->getByIDStatement->execute();
        $dbresult = $this->getByIDStatement->fetchAll(PDO::FETCH_ASSOC);
        foreach($dbresult as $r){
            $site=$r['siteIDTo'];
        }
        return $site;
    }
    private function getOrderByQuery($selectString) {
        $result = [];
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['txnID'];
                $name = $r['siteIDTo'];
                $prov = $r['siteIDFrom'];
                $add=$r['status'];
                $city=$r['shipDate'];
                $coun=$r['txnType'];
                $post=$r['createdDate'];
                $phone=$r['deliveryID'];
                $emerg=$r['emergencyDelivery'];
                $obj = new order($id, $name, $prov, $add, $city, $coun, $post, $phone, $emerg);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }
        return $result;
    }
    public function Order($order){
        $success=false;
        try{
        $to = $order->getTo();
        $ship=$order->getShipID();
        $em =$order->getEm();
        $eme=0;
        if($em==true){
            $eme=1;
        }
        $this->trans->bindParam(":to", $to);
        $this->trans->bindParam(":ship", $ship);
        $this->trans->bindParam(":emergency", $eme);
        $this->trans->execute();
        $success=true;
        }
        catch(Exception $ex){
            $success=$ex->getMessage();
        }
        $a=new auditAccessor();
        $a->Audit('Store Order', $_SESSION['id'], 'Order Created for Store', $_SESSION['site']);
        return $success;
    }
    public function onlineOrder($order, $name, $phone, $email){
        $success=false;
        $note ="Name: ".$name." Email: ".$email." Phone: ".$phone;
        try{
        $to = $order->getTo();
        $em =$order->getEm();
        $eme=0;
        if($em==true){
            $eme=1;
        }
        $this->online->bindParam(":to", $to);
        $this->online->bindParam(":emergency", $eme);
        $this->online->bindParam(":note", $note);
        $this->online->execute();
        $success=true;
        }
        catch(Exception $ex){
            $success=$ex->getMessage();
        }
        $a=new auditAccessor();
        $a->Audit('Online', 1, 'Online Order Created by customer', $_SESSION['site']);
        return $success;
    }
    public function Ready($item){
        try{
            $this->ready->bindParam("id", $item);
            $this->ready->execute();
            $a=new auditAccessor();
            $a->Audit('Store Order', $_SESSION['id'], 'Order has been readied', $_SESSION['site']);
            return 1;
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
    }
    public function applyItems($items, $quantity){
        try{
        $count=0;
        $this->getrecent->execute();
        $result=$this->getrecent->fetchAll(PDO::FETCH_ASSOC);
        $id=0;
        foreach($result as $r)
        {
         $id=$r['txnID'];   
        }
        $item = array_values($items);
        $quant = array_values($quantity);
        while ($count < count($items)){
           $this->item = $this->conn->prepare($this->itemstr);
           $this->item->bindParam(":txn", $id);
           $this->item->bindParam(":id", $item[$count]);
           $this->item->bindParam(":quantity", $quant[$count]);
           $this->item->execute();
           $count+=1;
    }
          return 1;
    }
    catch(Exception $ex){
        return $ex->getMessage();
    }
    }
    /**
     * Gets all menu items.
     * 
     * @return array MenuItem objects, possibly empty
     */
    public function submitOrder($id){
        try{
            $this->submit->bindParam(":id", $id);
            $this->submit->execute();
            $a=new auditAccessor();
            $a->Audit('Store Order', $_SESSION['id'], 'Order has been submitted to warehouse', $_SESSION['site']);
            return 1;
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
    }
    public function updateOrder($id, $items, $quantity){
        try{
            $count = 0;
            $this->process->bindParam(":id", $id);
            $this->process->execute();
        while($count < count($items)){
            $ia = new itemAccessor();
            $id->moveItem($items[$count], $quantity[$count]);
            $count++;
        }
        $a=new auditAccessor();
        $a->Audit('Store Order', $_SESSION['id'], 'Order updated', $_SESSION['site']);
        return 1;
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
    }
    public function Complete($id){
        try{
            $count=0;
            $this->closeStatement->bindParam(":id", $id);
            $this->closeStatement->execute();
            $success=1;
        } catch (Exception $ex) {
            $success=$ex->getMessage();
        }
        $a=new auditAccessor();
        $a->Audit('Store Order', $_SESSION['id'], 'Order Completed', $_SESSION['site']);
        return $success;
    }
    public function Deliver($id){
        try{
            $stmt = $this->DeliveryState->bindParam(":id", $id);
            $success= $this->DeliveryState->execute();
            $success = 1;
        } catch (Exception $ex) {
            $success=$ex->getMessage();
        }
        $a=new auditAccessor();
        $a->Audit('Store Order', $_SESSION['id'], 'Order Delivered', $_SESSION['site']);
        return $success;
    }
    public function Transport($id){
        try{
            $this->transStatement->bindParam(":id", $id);
            $success= $this->transStatement->execute();
            $success = 1;
        } catch (Exception $ex) {
            $success=$ex->getMessage();
        }
        $a=new auditAccessor();
        $a->Audit('Gain', $_SESSION['id'], 'Order on its way', $_SESSION['site']);
        return $success;
    }
    public function pickup($id, $distance, $size){
        try{
            $this->deliverState->bindParam(":distance", $distance);
            $this->deliverState->bindParam(":size", $size);
            $this->deliverState->execute();
            $this->pickupStatement->bindParam(":id", $id);
            $success= $this->pickupStatement->execute();
            $success = $this->pickupStatement->rowCount();
        } catch (Exception $ex) {
            $success=false;
        }
        $a=new auditAccessor();
        $a->Audit('Store Order', $_SESSION['id'], 'Deiver has collected Order', $_SESSION['site']);
        return $success;
    }
    public function getAllOrders() {
        return $this->getOrderByQuery("select * from txn");
    }
    public function getOnlineOrders($location) {
        $result = [];
        try {   
            $this->onlineOrder->bindParam(":loc", $location);
            $this->onlineOrder->execute();
            $dbresults=$this->onlineOrder->fetchAll(PDO::FETCH_ASSOC);
                foreach ($dbresults as $r) {
                $id = $r['txnID'];
                $name = $r['siteIDTo'];
                $prov = $r['siteIDFrom'];
                $add=$r['status'];
                $city=$r['shipDate'];
                $coun=$r['txnType'];
                $post=$r['createdDate'];
                $phone=$r['deliveryID'];
                $emerg=$r['emergencyDelivery'];
                $obj = new order($id, $name, $prov, $add, $city, $coun, $post, $phone, $emerg);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        return $result;
    }
    public function operation($place, $type, $note){
        $this->oppe->bindParam(":to", $place);
        $this->oppe->bindParam(":type", $type);
        $this->oppe->bindParam(":note", $note);
        $this->oppe->execute();
        $a=new auditAccessor();
        $a->Audit($type, $_SESSION['id'], 'opperation done', $_SESSION['site']);
        return 1;
    }
    public function getAllOperators(){
        $result=[];
        try{
            $this->op->execute();
            $dbresults=$this->op->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['txnID'];
                $name = $r['siteIDTo'];
                $prov = $r['siteIDFrom'];
                $add=$r['status'];
                $city=$r['shipDate'];
                $coun=$r['txnType'];
                $post=$r['createdDate'];
                $phone=$r['deliveryID'];
                $emerg=$r['emergencyDelivery'];
                $obj = new order($id, $name, $prov, $add, $city, $coun, $post, $phone, $emerg);
                array_push($result, $obj);
            }
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
        return $result;
    }
    public function getOnlineOrder($location) {
        $result = [];
        try {   
            $param="%".$location."%";
            $this->onlineOrd->bindParam(":name", $param);
            $this->onlineOrd->execute();
            $dbresults=$this->onlineOrd->fetchAll(PDO::FETCH_ASSOC);
                foreach ($dbresults as $r) {
                $id = $r['txnID'];
                $name = $r['siteIDTo'];
                $prov = $r['siteIDFrom'];
                $add=$r['status'];
                $city=$r['shipDate'];
                $coun=$r['txnType'];
                $post=$r['createdDate'];
                $phone=$r['deliveryID'];
                $emerg=$r['emergencyDelivery'];
                $obj = new order($id, $name, $prov, $add, $city, $coun, $post, $phone, $emerg);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }

        return $result;
    }
    public function getOrderItems($id){
        $result=[];
        try{
            $this->getOrderItems->bindParam(":id", $id);
            $this->getOrderItems->execute();
            $dbresults=$this->getOrderItems->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $desc=$r['description'];
                $cost = $r['costPrice'];
                $weight=$r['weight'];
                $quantity=$r['quantity'];
                $caseSize=$r['caseSize'];
                $obj = new Item($id, $name,'e', $desc, 'e', $cost, 1, $weight, $quantity, 1, $caseSize, 1, 1);
                array_push($result, $obj);
            }
        } catch (Exception $ex) {
            $result=$ex->getMessage();
        }
        return $result;
    }
    public function getOrderItemss($id, $id2){
        $result=[];
        try{
            $stmt=$this->conn->prepare($this->getOrderItemsStr);
            $stmt->bindParam(":id", $id2);
            $this->getOrderItems->bindParam(":id", $id);
            $this->getOrderItems->execute();
            $dbresults=$this->getOrderItems->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $desc=$r['description'];
                $cost = $r['costPrice'];
                $weight=$r['weight'];
                $quantity=$r['quantity'];
                $caseSize=$r['caseSize'];
                $obj = new Item($id, $name,'e', $desc, 'e', $cost, 1, $weight, $quantity, 1, $caseSize, 1, 1);
                array_push($result, $obj);
            }
            $stmt->execute();
            $dbresult2=$stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresult2 as $e) {
                $id = $e['itemID'];
                $name = $e['name'];
                $desc=$e['description'];
                $cost = $e['costPrice'];
                $weight=$e['weight'];
                $quantity=$e['quantity'];
                $caseSize=$e['caseSize'];
                $obj = new Item($id, $name,'e', $desc, 'e', $cost, 1, $weight, $quantity, 1, $caseSize, 1, 1);
                array_push($result, $obj);
            }
        } catch (Exception $ex) {
            $result=$ex->getMessage();
        }
        return $result;
    }
    public function Cancel($id){
         try{
            $this->cancel->bindParam(":id", $id);
            $success=$this->cancel->execute();
            $success=$this->cancel->rowCount();
        } catch (Exception $ex) {
            $success=$ex->getMessage();
        }
        $a=new auditAccessor();
        $a->Audit('Rejected', $_SESSION['id'], 'Order rejected', $_SESSION['site']);
        return $success;
    }
    public function checkTransaction($location){
        $arr=[];
        $result=1;
        $this->checktrans->bindParam(":site", $location);
        $this->checktrans->execute();
        $dbresult=$this->checktrans->fetchAll(PDO::FETCH_ASSOC);
        foreach ($dbresult as $r){
            array_push($arr, $r['status']);
        }
        foreach($arr as $e){
         if($e!=='CLOSED'){
            $result=0;
        }   
        }
        return $result;
    }
    public function getOrderId($location){
        $id=0;
        $this->checktrans->bindParam(":site", $location);
        $this->checktrans->execute();
        $dbresult=$this->checktrans->fetchAll(PDO::FETCH_ASSOC);
        foreach ($dbresult as $r){
            $id=$r['txnID'];
        }
         return $id;
        }
}
    /**
     * Updates a menu item in the database.
     * 
     * @param MenuItem $item an object of type MenuItem, the new values to replace the database's current values
     * @return boolean indicates if the item was updated
     */
