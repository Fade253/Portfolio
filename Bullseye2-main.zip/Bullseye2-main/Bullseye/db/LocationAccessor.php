<?php
$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/Bullseye';
require_once 'DatabaseConnecter.php';
require_once ($projectRoot. '/db/auditAccessor.php');
require_once ($projectRoot . '/entities/Location.php');

class LocationAccessor {
    private $warehouseDistState="select distanceFromWH from site where siteID=:id";
    private $getByIDStatementString = "select * from site where siteID = :id";
    private $addEmployeeStatementString="insert into site values (null, :name, :province, :address, null, :city, 'Canada', :postal, :phone, :day, :distance, :type, null, 1)";
    private $updateUserStatementString="update site set name=:name, provinceID=:province, address=:address, city=:city, postalCode=:postal, phone=:phone, dayOfWeek=:day, siteType=:type, active=:active where siteID=:id";
    private $deleteStatementString="update site set active=0 where siteID= :site";
    private $conn = NULL;
    private $waredist=NULL;
    private $getByIDStatement = NULL;
    private $deleteStatement = NULL;
    private $insertStatement = NULL;
    private $updateStatement = NULL;

    // Constructor will throw exception if there is a problem with ConnectionManager,
    // or with the prepared statements.
    public function __construct() {
        $cm = new Connector();

        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->getByIDStatement = $this->conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }
        $this->waredist=$this->conn->prepare($this->warehouseDistState);
        if (is_null($this->waredist)) {
            throw new Exception("bad statement: '" . $this->warehouseDistState . "'");
        }
        $this->deleteStatement = $this->conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("bad statement: '" . $this->deleteStatementString . "'");
        }
        $this->updateStatement = $this->conn->prepare($this->updateUserStatementString);
         if (is_null($this->updateStatement)) {
            throw new Exception("bad statement: '" . $this->updateUserStatementString . "'");
        }
        $this->insertStatement = $this->conn->prepare($this->addEmployeeStatementString);
        if (is_null($this->insertStatement)) {
            throw new Exception("bad statement: '" . $this->addEmployeeStatementString . "'");
        }

        //$this->updateStatement = $this->conn->prepare($this->updateStatementString);
        //if (is_null($this->updateStatement)) {
        //    throw new Exception("bad statement: '" . $this->updateStatementString . "'");
       //}
    }

    /**
     * Gets menu items by executing a SQL "select" statement. An empty array
     * is returned if there are no results, or if the query contains an error.
     * 
     * @param String $selectString a valid SQL "select" statement
     * @return array MenuItem objects
     */
    public function getWareDist($location){
        $result=0;
        $this->waredist->bindParam(":id", $location);
        $this->waredist->execute();
        $dbresult=$this->waredist->fetchALL(PDO::FETCH_ASSOC);
        foreach($dbresult as $e){
            $result = $e['distanceFromWH'];
        }
        return $result;
    }
    private function getLocationsByQuery($selectString) {
        $result = [];
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($dbresults as $r) {
                $id = $r['siteID'];
                $name = $r['name'];
                $prov = $r['provinceID'];
                $add=$r['address'];
                $city=$r['city'];
                $coun=$r['country'];
                $post=$r['postalCode'];
                $phone=$r['phone'];
                $dow=$r['dayOfWeek'];
                $dist=$r['distanceFromWH'];
                $type=$r['siteType'];
                $active=$r['active'];
                $obj = new Location($id, $name, $prov, $add, $city, $coun, $post, $phone, $dow, $dist, $type, $active);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }

        return $result;
    }
    public function getLocation($id){
        $this->getByIDStatement->bindParam(":id", $id);
        $this->getByIDStatement->execute();
        $dbresult=$this->getByIDStatement->fetchAll(PDO::FETCH_ASSOC);
        if($dbresult){
          $name=$dbresult[0]['name'];
          $day=$dbresult[0]['dayOfWeek'];
          $loc=new Location(0, $name, 'E', 'E', 'E', 'E', 'E', 'E', $day, 'E', 'E', 'E');
        }
        return $loc;
    }
    /**
     * Gets all menu items.
     * 
     * @return array MenuItem objects, possibly empty
     */
    
    public function getAllLocations() {
        return $this->getLocationsByQuery("select * from site");
    }
    public function ExplodeLocation($id) {
        $success=false;
        $ded=$id->getID();
        try{
        $this->deleteStatement->bindParam(":site",$ded);
        $success=$this->deleteStatement->execute();
        $rc = $this->deleteStatement->rowCount();
        }
        catch (PDOException $e) {
            $success = false;
        }
        finally {
            if (!is_null($this->deleteStatement)) {
                $this->deleteStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Correction', $_SESSION['id'], 'Location has been shut down', $_SESSION['site']);
            }
    }
     return $success;
    }
    
    public function insertLocation($new) {
        $success = false;
        $name = $new->getName();
        $pro = $new->getProvince();
        $add = $new->getAddress();
        $city = $new->getCity();
        $post = $new->getPostal();
        $phone=$new->getPhone();
        $distance=$new->getDistance();        
        $day=$new->getDay();
        $type=$new->getType();
        try {
            //$this->insertStatement->bindParam(":empid", 1016);
            $this->insertStatement->bindParam(":name", $name);
            $this->insertStatement->bindParam(":province", $pro);
            $this->insertStatement->bindParam(":address", $add);
            $this->insertStatement->bindParam(":city", $city);
            $this->insertStatement->bindParam(":postal", $post);
            $this->insertStatement->bindParam(":phone", $phone);
            $this->insertStatement->bindParam(":day", $day);
            $this->insertStatement->bindParam(":distance", $distance);
            $this->insertStatement->bindParam(":type", $type);
            $success = $this->insertStatement->execute();// this doesn't mean what you think it means
        }
        catch (PDOException $e) {
            echo $e->getMessage();
        }
        finally {
            if (!is_null($this->insertStatement)) {
                $this->insertStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'New Location has been opened', $_SESSION['site']);
            }
            return $success;
        }
    }
    /**
     * Updates a menu item in the database.
     * 
     * @param MenuItem $item an object of type MenuItem, the new values to replace the database's current values
     * @return boolean indicates if the item was updated
     */
    public function updateLocation($new){
        $id=$new->getID();
        $name = $new->getName();
        $pro = $new->getProvince();
        $add = $new->getAddress();
        $city = $new->getCity();
        $post = $new->getPostal();
        $phone=$new->getPhone();
        $distance=$new->getDistance();        
        $day=$new->getDay();
        $type=$new->getType();
        $active=$new->getActive();
        try {
            $this->updateStatement->bindParam(":id", $id);
            $this->updateStatement->bindParam(":name", $name);
            $this->updateStatement->bindParam(":province", $pro);
            $this->updateStatement->bindParam(":address", $add);
            $this->updateStatement->bindParam(":city", $city);
            $this->updateStatement->bindParam(":postal", $post);
            $this->updateStatement->bindParam(":phone", $phone);
            $this->updateStatement->bindParam(":day", $day);
            $this->updateStatement->bindParam(":type", $type);
            $this->updateStatement->bindParam(":active", $active);
            $success = $this->updateStatement->execute();// this doesn't mean what you think it means
        }
        catch (PDOException $e) {
            $success=false;
        }
        finally {
            if (!is_null($this->updateStatement)) {
                $this->updateStatement->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Correction', $_SESSION['id'], 'Location information corrected', $_SESSION['site']);
            }
            return $success;
        }
    }
}

