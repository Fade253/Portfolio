<?php
$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/Bullseye';
require_once 'DatabaseConnecter.php';
require_once ($projectRoot. '/db/auditAccessor.php');
class inventoryAccessor {
    private $getByIDStatementString = "select * from item where id = :id";
    private $addEmployeeStatementString="insert into site values (null, :name, :province, :address, null, :city, 'Canada', :postal, :phone, :day, :distance, :type, null, 1)";
    private $updateUserStatementString="update inventory set reorderThreshold=:reorder where itemID=:id";
    private $deleteStatementString="delete from site where siteID= :site";
    private $conn = NULL;
    private $getByIDStatement = NULL;
    private $deleteStatement = NULL;
    private $insertStatement = NULL;
    private $updateStatement = NULL;

    // Constructor will throw exception if there is a problem with ConnectionManager,
    // or with the prepared statements.
    public function __construct() {
        $cm = new Connector();

        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->getByIDStatement = $this->conn->prepare($this->getByIDStatementString);
        if (is_null($this->getByIDStatement)) {
            throw new Exception("bad statement: '" . $this->getAllStatementString . "'");
        }

        $this->deleteStatement = $this->conn->prepare($this->deleteStatementString);
        if (is_null($this->deleteStatement)) {
            throw new Exception("bad statement: '" . $this->deleteStatementString . "'");
        }
        $this->updateStatement = $this->conn->prepare($this->updateUserStatementString);
         if (is_null($this->updateStatement)) {
            throw new Exception("bad statement: '" . $this->updateUserStatementString . "'");
        }
        $this->insertStatement = $this->conn->prepare($this->addEmployeeStatementString);
        if (is_null($this->insertStatement)) {
            throw new Exception("bad statement: '" . $this->addEmployeeStatementString . "'");
        }
    }
    private function getInventoryByQuery($selectString) {
        $result = [];
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $quan = $dbresults['quantity'];
            array_push($result, $quan);
            }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
            }
        }

        return $result;
    }
    public function updateThreshold($id, $reorder){
        try{
            $this->updateStatement->bindParam(':reorder', $reorder);
            $this->updateStatement->bindParam(':id', $id);
            $this->updateStatement->execute();
            $a=new auditAccessor();
                $a->Audit('Correction', $_SESSION['id'], 'Threshold changed', $_SESSION['site']);
            return 1;
            #$a = new auditAccessor($date);
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
    }
    public function getQuantity($id){
        return $this->getInventoryByQuery("select quantity from inventory where itemID="+$id);
    }
    public function getAllItems() {
        return $this->getItemsByQuery("select * from item");
    }
}
