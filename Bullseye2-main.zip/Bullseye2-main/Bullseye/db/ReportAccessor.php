<?php
$projectRoot = $_SERVER['DOCUMENT_ROOT'] . '/Bullseye';
require_once 'DatabaseConnecter.php';
require_once ($projectRoot . '/entities/txn.php');
require_once ($projectRoot.'/entities/User.php');
require_once ($projectRoot. '/entities/Report.php');
require_once ($projectRoot.'/entities/order.php');
require_once ($projectRoot.'/entities/Item.php');
require_once ($projectRoot. '/db/auditAccessor.php');
class ReportAccessor {
    private $getUserReport="select * from employee order by positionID, siteID";
    private $deliveryRep="select delivery.*, txn.* from delivery inner join txn where txn.deliveryID=delivery.deliveryID and txn.createdDate between :date1 and CURDATE()";
    private $supplier="select * from txn where txntype='Supplier Order' and createdDate between :date1 and CURDATE()";
    private $getStoreData="select * from txn where txntype='Loss' or txntype='Return' or txntype='Damage' and createdDate between :date1 and CURDATE() order by txntype, siteIDto";
    private $backOrder="select * from txn where txntype='Back Order' and createdDate between :date1 and CURDATE() order by siteIDto";
    private $getStoreOrders="select * from txn where txnType='Store Order' and emergencyDelivery=0 and createdDate between :date1 and CURDATE()";
    private $makeRecipt="select item.* txnitems.* from item inner join txntems on item.itemID where txnID=:id";
    private $inventoryReport="select inventory.*, item.* from inventory inner join item on inventory.itemID=item.itemID where inventory.siteID=:site";
    private $emergencyState="select * from txn where emergencyDelivery=1 and createdDate BETWEEN :date1 and CURDATE() order by siteIDTo";
    private $conn = NULL;
    private $deli=NULL;
    private $user=NULL;
    private $supp = NULL;
    private $storedat = NULL;
    private $backord = NULL;
    private $store = NULL;
    private $eme=NULL;
    private $inv=NULL;
    private $rec=NULL;

    // Constructor will throw exception if there is a problem with ConnectionManager,
    // or with the prepared statements.
    public function __construct() {
        $cm = new Connector();

        $this->conn = $cm->connect_db();
        if (is_null($this->conn)) {
            throw new Exception("no connection");
        }
        $this->supp = $this->conn->prepare($this->supplier);
        if (is_null($this->supp)) {
            throw new Exception("bad statement: '" . $this->supplier . "'");
        }
        $this->deli = $this->conn->prepare($this->deliveryRep);
        if (is_null($this->deli)) {
            throw new Exception("bad statement: '" . $this->deliveryRep . "'");
        }
        $this->user = $this->conn->prepare($this->getUserReport);
        if (is_null($this->user)) {
            throw new Exception("bad statement: '" . $this->getUserReport . "'");
        }
        $this->storedat = $this->conn->prepare($this->getStoreData);
        if (is_null($this->storedat)) {
            throw new Exception("bad statement: '" . $this->getStoreDate . "'");
        }
        $this->store = $this->conn->prepare($this->getStoreOrders);
         if (is_null($this->store)) {
            throw new Exception("bad statement: '" . $this->getStoreOrders . "'");
        }
        $this->backord = $this->conn->prepare($this->backOrder);
        if (is_null($this->backord)) {
            throw new Exception("bad statement: '" . $this->backOrder . "'");
        }
        $this->eme = $this->conn->prepare($this->emergencyState);
        if (is_null($this->eme)) {
            throw new Exception("bad statement: '" . $this->emergenceyState . "'");
        }
        $this->inv = $this->conn->prepare($this->inventoryReport);
        if (is_null($this->inv)) {
            throw new Exception("bad statement: '" . $this->inventoryReport . "'");
        }
        $this->rec = $this->conn->prepare($this->makeRecipt);
        if (is_null($this->rec)) {
            throw new Exception("bad statement: '" . $this->makeRecipt . "'");
        }

        //$this->updateStatement = $this->conn->prepare($this->updateStatementString);
        //if (is_null($this->updateStatement)) {
        //    throw new Exception("bad statement: '" . $this->updateStatementString . "'");
       //}
    }

    /**
     * Gets menu items by executing a SQL "select" statement. An empty array
     * is returned if there are no results, or if the query contains an error.
     * 
     * @param String $selectString a valid SQL "select" statement
     * @return array MenuItem objects
     */
    private function getItemsByQuery($selectString) {
        $result = [];
        try {
            $stmt = $this->conn->prepare($selectString);
            $stmt->execute();
            $dbresults = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($dbresults as $r) {
                $id = $r['txnID'];
                $name = $r['siteIDTo'];
                $sku = $r['siteIDFrom'];
                $stat=$r['status'];
                $desc=$r['shipDate'];
                $cat = $r['txnType'];
                $whole=$r['createdDate'];
                $retail=$r['deliveryID'];
                $obj = new txn($id, $name, $sku, $stat, $desc, $cat, $whole, $retail);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($stmt)) {
                $stmt->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Order Report', $_SESSION['site']);
            }
        }

        return $result;
    }
    public function getAllInventory($loc){
        $result = [];
        try {
            $this->inv->bindParam(':site', $loc);
            $this->inv->execute();
            $dbresults = $this->inv->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['itemID'];
                $name = $r['name'];
                $sku = $r['sku'];
                $desc=$r['description'];
                $cat = $r['category'];
                $weight=$r['weight'];
                $whole=$r['costPrice'];
                $retail=$r['retailPrice'];
                $supp=$r['supplierID'];
                $site=$r['siteID'];
                $reorder=$r['reorderThreshold'];
                $quant=$r['quantity'];
                $size=$r['caseSize'];
                $obj = new Item($id, $name, $sku, $desc, $cat, $weight, $whole, $retail, $quant, $supp, $size, $site, $reorder);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($this->inv)) {
                $this->inv->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Inventory Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getDelivery($date1){
        $result=[];
        try{
            $this->deli->bindParam(":date1", $date1);
            $this->deli->execute();
            $dbresult=$this->deli->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresult as $r) {
                $id = $r['deliveryID'];
                $txn=$r['txnID'];
                $to = $r['siteIDTo'];
                $from=$r['siteIDFrom'];
                $distance=$r['distanceCost'];
                $obj = new Report($id, $txn, $to, $from, $distance, 'f', 'g', 'h', 'i', 'j');
                array_push($result, $obj);
            }
            $a=new auditAccessor();
            $a->Audit('Gain', $_SESSION['id'], 'Delivery Report', $_SESSION['site']);
        } catch (Exception $ex) {
            return $ex->getMessage();
        }
        return $result;
    }
    public function getBackOrder($date1){
        $result=[];
        try{
            $this->backord->bindParam(":date1", $date1);
            $this->backord->execute();
            $dbresults = $this->backord->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $txn=$r['txnID'];
                $to = $r['siteIDTo'];
                $from=$r['siteIDFrom'];
                $status=$r['status'];
                $ship=$r['shipDate'];
                $type=$r['txnType'];
                $created=$r['createdDate'];
                $delivery=$r['deliveryID'];
                $obj = new order($txn, $to, $from, $status, $ship, $type, $created, $delivery, 0);
                array_push($result, $obj);
            }
        } 
        catch (Exception $ex) {
            return $ex->getMessage();
        }
        finally{
            if(!is_null($this->backord)){
                $this->backord->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Back Order Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getLosses($date1){
        $result=[];
        try{
            $this->storedat->bindParam(":date1", $date1);
            $this->storedat->execute();
            $dbresults = $this->storedat->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $txn=$r['txnID'];
                $to = $r['siteIDTo'];
                $from=$r['siteIDFrom'];
                $status=$r['status'];
                $ship=$r['shipDate'];
                $type=$r['txnType'];
                $created=$r['createdDate'];
                $delivery=$r['deliveryID'];
                $obj = new order($txn, $to, $from, $status, $ship, $type, $created, $delivery, 0);
                array_push($result, $obj);
            }
        } 
        catch (Exception $ex) {
            return $ex->getMessage();
        }
        finally{
            if(!is_null($this->storedat)){
                $this->storedat->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Loss Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getStoreOrder($date1){
        $result=[];
        try{
            $this->store->bindParam(":date1", $date1);
            $this->store->execute();
            $dbresults = $this->store->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $txn=$r['txnID'];
                $to = $r['siteIDTo'];
                $from=$r['siteIDFrom'];
                $status=$r['status'];
                $ship=$r['shipDate'];
                $type=$r['txnType'];
                $created=$r['createdDate'];
                $delivery=$r['deliveryID'];
                $obj = new order($txn, $to, $from, $status, $ship, $type, $created, $delivery, 0);
                array_push($result, $obj);
            }
        } 
        catch (Exception $ex) {
            return $ex->getMessage();
        }
        finally{
            if(!is_null($this->store)){
                $this->store->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Store Order Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getEmergencyOrder($date1){
        $result=[];
        try{
            $this->eme->bindParam(":date1", $date1);
            $this->eme->execute();
            $dbresults = $this->eme->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $txn=$r['txnID'];
                $to = $r['siteIDTo'];
                $from=$r['siteIDFrom'];
                $status=$r['status'];
                $ship=$r['shipDate'];
                $type=$r['txnType'];
                $created=$r['createdDate'];
                $delivery=$r['deliveryID'];
                $obj = new order($txn, $to, $from, $status, $ship, $type, $created, $delivery, 0);
                array_push($result, $obj);
            }
        } 
        catch (Exception $ex) {
            return $ex->getMessage();
        }
        finally{
            if(!is_null($this->eme)){
                $this->eme->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Emergency Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getUserReport(){
        $result = [];
        try {
            $this->user->execute();
            $dbresults = $this->user->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $id = $r['employeeID'];
                $user = $r['username'];
                $pass = $r['password'];
                $firstname=$r['firstName'];
                $lastname=$r['lastName'];
                $email=$r['email'];
                $active=$r['active'];
                $locked=$r['locked'];
                $positionID=$r['positionID'];
                $siteID=$r['siteID'];              
                $obj = new User($id, $user, $pass, $firstname, $lastname, $email, $active, $locked, $positionID, $siteID);
                array_push($result, $obj);
            }
        }
        catch (Exception $e) {
            $result = $e;
        }
        finally {
            if (!is_null($this->user)) {
                $this->user->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'User Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getSupplierOrder($date1){
        $result=[];
        try{
            $this->supp->bindParam(":date1", $date1);
            $this->supp->execute();
            $dbresults = $this->supp->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dbresults as $r) {
                $txn=$r['txnID'];
                $to = $r['siteIDTo'];
                $from=$r['siteIDFrom'];
                $status=$r['status'];
                $ship=$r['shipDate'];
                $type=$r['txnType'];
                $created=$r['createdDate'];
                $delivery=$r['deliveryID'];
                $obj = new order($txn, $to, $from, $status, $ship, $type, $created, $delivery, 0);
                array_push($result, $obj);
            }
        } 
        catch (Exception $ex) {
            return $ex->getMessage();
        }
        finally{
            if(!is_null($this->supp)){
                $this->supp->closeCursor();
                $a=new auditAccessor();
                $a->Audit('Gain', $_SESSION['id'], 'Supplier Order Report', $_SESSION['site']);
            }
        }
        return $result;
    }
    public function getAllReports() {
        return $this->getItemsByQuery("select * from txn where txnType LIKE '%Order'");
    }
}