<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
            <select id="locations">
                <option value="4">Saint John</option>
                <option value="5">Sussex</option>
                <option value="6">Moncton</option>
                <option value="7">Dieppe</option>
                <option value="8">Oromocto</option>
                <option value="9">Fredricton</option>
                <option value="10">Miramichi</option>
            </select>
        <div>emergency?<input type="checkbox" id="emergency"></div>
        <button id="get">Get Items</button>
        <button id="confirm">Confirm items for online order</button>
        <button id="research">Search</button>
        <button id="DoneButton">Done</button>
        <button id="ready">Ready Online Order</button>
        <button id='backBtn'>Log Out</button>
        <table>
                <th>ID</th>
                <th>To</th>
                <th>Status</th>
                <th>Ship Date</th>
                <th>Information</th>
        </table>
        <script src="js/order.js"></script>
    </body>
</html> 

