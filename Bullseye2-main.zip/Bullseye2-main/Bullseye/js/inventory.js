let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    // add event handlers for buttons
    document.querySelector("#GetButton").addEventListener("click", getAllItems);
    document.querySelector("#search").addEventListener("change", getSearchItems);
    document.querySelector("#Order").addEventListener("click", order)
    //document.querySelector("#AddButton").addEventListener("click", addUser);
    document.querySelector("#UpdateButton").addEventListener("click", updateUser);
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#CancelButton").addEventListener("click", hideUpdatePanel);
    // add event handler for selections on the table
    document.querySelector("table").addEventListener("click", handleRowClick);
    hideUpdatePanel();
    getLocations();
};
function order(){
    window.location.replace("orderitems.php");
}
function resetUpdatePanel() {
    document.querySelector("#id").value = "";
    document.querySelector("#name").value="";
    document.querySelector("#address").value = "";
    document.querySelector("#post").value="";
    document.querySelector("#phone").value="506";
    document.querySelector("#dow").value="";
    document.querySelector("distance").value=0;
}

function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    document.querySelector("#UpdateButton").removeAttribute("disabled");
    fillUpdatePanel();
    addOrUpdate="update";
}
function getLocations(){
     let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildDrop(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// gets all items
function getAllItems() {
    let loc=document.querySelector('#locations').value;
    let url = "Item/get/"+loc;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getSearchItems() {
    let loc=document.querySelector('#locations').value;
    let search=document.querySelector('#search').value;
    let obj={
        location:loc
    };
    let url = "Item/search/"+search;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                console.log(resp);
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(obj));
}

// builds wth text from getAllItems
function buildTable(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html += "<td>"+row.quantity+"</td>";
        html +="<td>"+row.location+"</td>";
        html+="<td>"+row.reorder+"</td>";
        html+="<td>"+row.caseSize+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("select");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+(i+1)+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
//clears any selected elements
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
//hides update panel when loading data
function hideUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.add("hidden");
}
//reveals hen adding or updating
function showUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.remove("hidden");
}
//fills with information of clicked row
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    let id = items[0].innerHTML;
    let reorder= items[4].innerHTML;
    document.querySelector("#item").value=id;
    document.querySelector("#reorder").value=reorder;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    let item=document.querySelector("#item").value;
    let reorder=document.querySelector("#reorder").value;
    let date = getDate();
    let obj = {
        item:item,
        reorder:reorder,
        date:date
    }
    let url = "Inventory/reorder";
    let method = "PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp != 1) {
                console.log(resp);
                alert("something went wrong");
            } else {
                
            }
            getAllItems();
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
function getDate(){
        let dateobj=new Date();
        let year = dateobj.getFullYear();
        let month=dateobj.getMonth();
        if(month.toString().length < 2){
           month="0"+month;
        }
        let day=dateobj.getDay();
        if(day.toString().length < 2){
        day="0"+day;
        }
        let date=year+""+month+""+day;
        return date;
        }
//sets user to locked
//switches wide variable
function addUser() {
    addOrUpdate = "add";
    showUpdatePanel();
    document.querySelector("#id").disabled=false;
}
function updateUser() {
    addOrUpdate="update";
    showUpdatePanel();
    fillUpdatePanel();
}

function setIDFieldState(val) {
    let idInput = document.querySelector("#id");
    if (val) {
        idInput.removeAttribute("disabled");
    }
}


