let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    // add event handlers for buttons
    document.querySelector("#AddButton").addEventListener("click", addUser);
    document.querySelector("#DeleteButton").addEventListener("click", deleteLocation);
    document.querySelector("#UpdateButton").addEventListener("click", updateUser);
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#CancelButton").addEventListener("click", hideUpdatePanel);
    document.querySelector("#backBtn").addEventListener("click", backButton)
    // add event handler for selections on the table
    document.querySelector("table").addEventListener("click", handleRowClick);
    hideUpdatePanel();
    getAllItems();
};
function backButton()
{
    window.location.replace("index.php");
}
//resets update when adding
function resetUpdatePanel() {
    document.querySelector("#id").value = "";
    document.querySelector("#name").value="";
    document.querySelector("#address").value = "";
    document.querySelector("#post").value="";
    document.querySelector("#phone").value="506";
    document.querySelector("#dow").value="";
    document.querySelector("distance").value=0
}
//handles when a row is clicked
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    document.querySelector("#DeleteButton").removeAttribute("disabled");
    document.querySelector("#UpdateButton").removeAttribute("disabled");
    fillUpdatePanel();
    addOrUpdate="update";
}

// gets all items
function getAllItems() {
    let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
                hideUpdatePanel();
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    // disable Delete and Update buttons
    document.querySelector("#DeleteButton").setAttribute("disabled", "disabled");
    document.querySelector("#UpdateButton").setAttribute("disabled", "disabled");
}

// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html += "<td>" + row.id + "</td>";
        html += "<td>" + row.name + "</td>";
        html += "<td>" + row.province + "</td>";
        html += "<td>" + row.address +"</td>";
        html += "<td>" + row.city + "</td>";
        html += "<td>" + row.country + "</td>";
        html += "<td>" + row.postal + "</td>";
        html += "<td>" + row.phone + "</td>";
        html += "<td>" + row.type + "</td>";
        html += "<td>" + row.day + "</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
//clears any selected elements
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
//hides update panel when loading data
function hideUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.add("hidden");
}
//reveals hen adding or updating
function showUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.remove("hidden");
}
//fills with information of clicked row
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    let id = items[0].innerHTML;
    let name = items[1].innerHTML;
    let address = items[2].innerHTML;
    let city=items[4].innerHTML;
    let postal = items[6].innerHTML;
    let phone=items[7].innerHTML;
    let day=items[8].innerHTML;
    let type = items[9].innerHTML;
    document.querySelector("#id").value=id;
    document.querySelector("#name").value=name;
    document.querySelector("#address").value = address;
    document.querySelector("#city").value=city;
    document.querySelector("#post").value = postal;
    document.querySelector("#phone").value=phone;
    document.querySelector("#dow").value=day;
    document.querySelector("#type").value=type;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let id;
    let bool;
    if(document.querySelector("#id").value!==""){
        id=document.querySelector("#id").value;
    }
    else{
        id=0
    }
    let name = document.querySelector("#name").value;
    let province = document.querySelector("#province").value;
    let address = document.querySelector("#address").value;
    let city = document.querySelector("#city").value;
    let post=document.querySelector("#post").value;
    let phone = document.querySelector("#phone").value;
    let dist=document.querySelector("#distance").value;
    let day = document.querySelector("#dow").value;
    let type = document.querySelector("#type").value;
    let active=document.querySelector("#active").checked;
    if(active){
        bool=1
    }
    else{
        bool=0
    }
    let obj = {
        id:id,
        name: name,
        province: province,
        address: address,
        city: city,
        post: post,
        phone: phone,
        day: day,
        dist:dist,
        type: type,
        active:bool
    };
    console.log(obj)
    // Make AJAX call to add or update the record in the database.
    let url = "Location/Edit/"+id;
    let method = (addOrUpdate === "add") ? "POST":"PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp != 1) {
                console.log(resp);
                alert("something went wrong");
            } else {
                
            }
            getAllItems();
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
//sets user to locked
function deleteLocation() {
    let id=document.querySelector("#id").value
    // AJAX
    let url = "Location/Ratio/" + id; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== 1) {
                alert("ratio");
                console.log(resp);
            } else {
                console.log(resp);
                getAllItems();
            }
        }
    };
    xmlhttp.open("DELETE", url, true); // must be POST
    xmlhttp.send(id);
    }
//switches wide variable
function addUser() {
    addOrUpdate = "add";
    showUpdatePanel();
    document.querySelector("#id").disabled=false;
}
function updateUser() {
    addOrUpdate="update";
    showUpdatePanel();
    fillUpdatePanel();
}

function setIDFieldState(val) {
    let idInput = document.querySelector("#id");
    if (val) {
        idInput.removeAttribute("disabled");
    }
}

