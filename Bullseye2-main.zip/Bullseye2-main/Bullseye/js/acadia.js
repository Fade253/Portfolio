let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    
    // add event handler for selections on the table
    document.querySelector("#DoneButton").addEventListener("click", pickupOrder);
    document.querySelector("#getOrders").addEventListener("click", getAllItems);
    document.querySelector("#builditem").addEventListener("click", getOrderItems);
    document.querySelector("#getDistance").addEventListener("click", getDistance);
    document.querySelector("table").addEventListener("click", handleRowClick);
    getAllItems();
};
function pickupOrder(){
    let id = document.querySelector("#id").value;
    let truck = document.querySelector('select').value;
    let distance = document.querySelector("#distance").value;
    let obj ={
        id:id,
        size:truck,
        distance:distance
    };
    let url = "Order/pickup";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                alert("order has been picked up");
                moveItems();
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(obj));
}
function moveItems(){
    let id=document.querySelector("#id").value;
    let items=[];
    let quantity=[];
    let loc=document.querySelector("#site").value;
    let table=document.querySelector("table");
    let row=table.querySelectorAll("tr");
    for (let i = 1; i<row.length; i++)
    {
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[3].textContent);
            quantity.push(val);
        }
    let obj={
        item:items,
        quantity:quantity,
        loc:9999
    };
    let url = "Order/Move/"+id;
    let method = "PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== '1') {
                console.log(resp);
                alert("something went wrong");
            } else {
                alert("items have been moved");
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
function handleRowClick(e) {
    //add style to parent of clicked cell
    e.target.parentElement.classList.add("highlighted");
    fillUpdatePanel();
}
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    console.log(items[0].innerHTML);
    let id = items[0].innerHTML;
    let loc = items[1].innerHTML;
    document.querySelector("#id").value=id;
    document.querySelector("#site").value=loc;
}
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
function getDistance(){
    let distInput=document.querySelector("#distance");
    let selected=document.querySelector(".highlighted");
    let location=parseInt(selected.childNodes[1].innerHTML);
    let url="Order/distance/"+location;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                distInput.value=resp;
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getAllItems() {
    let url = "Order/get";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getOrderItems() {
    let selected=document.querySelectorAll(".highlighted");
    let order1=selected[0].querySelectorAll("td");
    let id2=0;
    if(selected.length !==2){
        id2=0;
    }
    else{
        let order2=selected[1].querySelectorAll("td");
        id2=order2[0].innerHTML;
    }
    let id1=order1[0].innerHTML;
    if(order1[3].innerHTML!=="READY"){
        alert("order is not redy for pickup");
    }
    else{
    let url = "Order/get/"+id1+"/"+id2;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable2(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
    }
}
function buildTable2(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>Item</th>\n\
<th>Name</th>\n\
<th>Weight</th>\n\
<th>Quantity</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.weight+"</td>";
        html+="<td>"+row.quantity+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function buildTable(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>ID</th>\n\
<th>To</th>\n\
<th>From</th>\n\
<th>Status</th>\n\
<th>DeliveryID</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.to+"</td>";
        html+="<td>"+row.from+"</td>";
        html+="<td>"+row.status+"</td>";
        html+="<td>"+row.delivery+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}