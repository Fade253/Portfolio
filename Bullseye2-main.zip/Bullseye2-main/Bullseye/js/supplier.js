let addOrUpdate;
let ordercount=0;
let orderDate='';
// to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#DoneButton").addEventListener("click", checkcount);
    document.querySelector("#search").addEventListener("change", getSearchItems);
    document.querySelector("#DateButton").addEventListener("click", getStoreDate);
    document.querySelector("#submit").addEventListener("click", submitOrder);
    document.querySelector("#get").addEventListener("click", getAllItems);
    // add event handler for selections on the table
    getAllItems();
};
function submitOrder(){
    window.location.replace("StoreOrder.php")
}
function getSearchItems() {
    let loc=document.querySelector('#locations').value;
    let search=document.querySelector('#search').value;
    if(search===''){
        getAllItems();
    }
    else{
        
    let obj={
        location:loc
    };
    let url = "Item/search/"+search;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                console.log(resp);
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(obj));
    }
}
// gets all items
function getAllItems() {
    let url = "Item/supplier";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        let num = i+1;
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.wholecost+"</td>";
        html+="<td>"+row.weight+"</td>";
        html+="<td>"+row.caseSize+"</td>";
        html += "<td><input id='cases"+num+"' type='number' value=0></td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function checkcount(){
    let url = "Order/store/"+1;
    let method = "GET";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0||resp!=="1") {
            alert('Warehouse ether has an order already, or there is an error, ether way im going to try to apply the items');
            addItemsToOrder();
            } else {
                alert('Warehouse can make an order');
                processForm();
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send();
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("select");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+row.id+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
// processes when done is clicked, getting data and sending an object for operation
function addItemsToOrder(){
    let items= [];
    let quantity=[];
    let dummy = "suck";
    let table = document.querySelector("table");
    let row=table.querySelectorAll("tr");
    for (let i = 1; i<row.length;i++){
        let item = document.querySelector("#cases"+i);
        if(item.value > 0){
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[4].textContent);
            let quan = parseInt(item.value);
            quantity.push(quan * val);
        }
    }
    let obj={
        items:items,
        quantity:quantity
    };
    let url = "Order/items/"+dummy;
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                console.log(resp);
                alert("there was ether another error, or the same error from last time");
            } else {
                alert('items have been attatched to order');
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
function processForm() {
    // Get data from the form and build an object.
    let ship = orderDate;
    let obj={
        ship:ship
    };
    let url = "Order/supplier";
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp!=="1") {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert('Order has been created');
                addItemsToOrder();
            }
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
function getStoreDate(){
    let url = "Location/spec/"+1; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                let text=JSON.parse(resp);
                orderDate = next(text.day);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getDate(dateobj){
        let newdate= new Date(dateobj);
        let year = newdate.getFullYear();
        let month=newdate.getMonth();
        if(month.toString().length < 2){
           month="0"+month;
        }
        let day=newdate.getDay();
        if(day.toString().length < 2){
        day="0"+day;
        }
        let date=year+""+month+""+day;
        return date;
}
var days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
function next(day) {
    let today = new Date();
    let today_day = today.getDay();
    day = day.toLowerCase();
    for (var i = 7; i--;) {
        if (day === days[i]) {
            day = (i <= today_day) ? (i + 7) : i;
            break;
        }
    }
    let daysUntilNext = day - today_day;
    let nextDate= new Date().setDate(today.getDate() + daysUntilNext);
    return getDate(nextDate);
}

