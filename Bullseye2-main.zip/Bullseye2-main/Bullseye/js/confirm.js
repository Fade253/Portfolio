let addOrUpdate;
let onlineOrder;// to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    // add event handlers for buttons
    document.querySelector("#GetButton").addEventListener("click", getAllItems);
    document.querySelector("#confirm").addEventListener("click", processForm);
    document.querySelector("#getLocation").addEventListener("click", getLocation);
    // add event handler for selections on the table
};
function getLocation(){
    let loc=getAllUrlParams();
    onlineOrder=true;
    document.querySelector("#location").value=loc['loc'];
}
function getAllUrlParams(url) {
  // get query string from url (optional) or window
  var queryString = url ? url.split('?')[1] : window.location.search.slice(1);
  // we'll store the parameters here
  var obj = {};
  // if query string exists
  if (queryString) {
    // stuff after # is not part of query string, so get rid of it
    queryString = queryString.split('#')[0];

    // split our query string into its component parts
    var arr = queryString.split('&');

    for (var i = 0; i < arr.length; i++) {
      // separate the keys and the values
      var a = arr[i].split('=');
      // set parameter name and value (use 'true' if empty)
      var paramName = a[0];
      var paramValue = typeof (a[1]) === 'undefined' ? true : a[1];

      // (optional) keep case consistent
      paramName = paramName.toLowerCase();
      if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();

      // if the paramName ends with square brackets, e.g. colors[] or colors[2]
      if (paramName.match(/\[(\d+)?\]$/)) {

        // create key if it doesn't exist
        var key = paramName.replace(/\[(\d+)?\]/, '');
        if (!obj[key]) obj[key] = [];

        // if it's an indexed array e.g. colors[2]
        if (paramName.match(/\[\d+\]$/)) {
          // get the index value and add the entry at the appropriate position
          var index = /\[(\d+)\]/.exec(paramName)[1];
          obj[key][index] = paramValue;
        } else {
          // otherwise add the value to the end of the array
          obj[key].push(paramValue);
        }
      } else {
        // we're dealing with a string
        if (!obj[paramName]) {
          // if it doesn't exist, create property
          obj[paramName] = paramValue;
        } else if (obj[paramName] && typeof obj[paramName] === 'string'){
          // if property does exist and it's a string, convert it to an array
          obj[paramName] = [obj[paramName]];
          obj[paramName].push(paramValue);
        } else {
          // otherwise add the property
          obj[paramName].push(paramValue);
        }
      }
    }
  }
  return obj;
}
// gets all items
function getAllItems() {
    let id=getAllUrlParams();
    let url = "Order/txn/"+id['id'];
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}

// builds wth text from getAllItems
function buildTable(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let num = i+1;
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html += "<td>"+row.quantity+"</td>";
        html +="<td><input id='item"+num+"' type='checkbox'></td>"
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}

// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    let id=getAllUrlParams();
    let items=[];
    let quantity=[];
    let table =document.querySelector('table');
    let row=table.querySelectorAll('tr');
    for (let i = 1; i<row.length; i++)
    {
        let item = document.querySelector("#item"+i);
        if(item.checked ===true){
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[2].textContent);
            quantity.push(val);
        }
        else if(item.checked===false){
            alert("you have left an item unchecked, please resolve whatever the issue is with the driver if possible, otherwise check the item and mark it wasnt recieved");
            return;
        }
    }
    let url = "Order/Conclude/"+id['id'];
    let method = "PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp != '1') {
                console.log(resp);
                alert("something went wrong");
            } else {
                alert("order complete")
                moveItems();
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send();
}
function moveOnline(){
    let id = getAllUrlParams();
    let loc=document.querySelector("#location").value;
    let items=[];
    let quantity=[];
    let table =document.querySelector('table');
    let row=table.querySelectorAll('tr');
    for (let i = 1; i<row.length; i++)
    {
        let item = document.querySelector("#item"+i);
        if(item.checked ===true){
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[2].textContent);
            quantity.push(val);
        }
    }
    let obj={
        loc:loc,
        item:items,
        quantity:quantity
    };
    let url = "Order/onmove/"+id['id'];
    let method = "PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== '1') {
                console.log(resp);
                alert("something went wrong");
            } else {
                alert("items have been moved");
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
function moveItems(){
    if(onlineOrder){
        moveOnline();
    }
    else{
    let id = getAllUrlParams();
    let loc=document.querySelector("#location").value;
    let items=[];
    let quantity=[];
    let table =document.querySelector('table');
    let row=table.querySelectorAll('tr');
    for (let i = 1; i<row.length; i++)
    {
        let item = document.querySelector("#item"+i);
        if(item.checked ===true){
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[2].textContent);
            quantity.push(val);
        }
    }
    let obj={
        loc:loc,
        item:items,
        quantity:quantity
    };
    let url = "Order/Move/"+id['id'];
    let method = "PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== '1') {
                console.log(resp);
                alert("something went wrong");
            } else {
                alert("items have been moved");
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
}
function getDate(){
        let dateobj=new Date();
        let year = dateobj.getFullYear();
        let month=dateobj.getMonth();
        if(month.toString().length < 2){
           month="0"+month;
        }
        let day=dateobj.getDay();
        if(day.toString().length < 2){
        day="0"+day;
        }
        let date=year+""+month+""+day;
        return date;
        }
//switches wide variable
function addUser() {
    addOrUpdate = "add";
    showUpdatePanel();
    document.querySelector("#id").disabled=false;
}
function updateUser() {
    addOrUpdate="update";
    showUpdatePanel();
    fillUpdatePanel();
}

function setIDFieldState(val) {
    let idInput = document.querySelector("#id");
    if (val) {
        idInput.removeAttribute("disabled");
    }
}

