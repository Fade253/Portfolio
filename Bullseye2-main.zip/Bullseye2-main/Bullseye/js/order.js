let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#get").addEventListener("click", getAllItems);
    document.querySelector("#confirm").addEventListener("click", confirmOrder);
    document.querySelector("#ready").addEventListener("click", ReadyOrder);
    document.querySelector("table").addEventListener("click", handleRowClick);
    // add event handler for selections on the table
    getLocations();
};
function confirmOrder(){
    let order=document.querySelector(".highlighted");
    let id=order.childNodes[0].innerHTML;
    window.location.replace("warehouse.php?id="+id);
}
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    addOrUpdate="update";
}
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
function ReadyOrder(){
    let selected = document.querySelector(".highlighted");
    let status = selected.childNodes[2].innerHTML;
    console.log(status);
    if(status!=="PROCESSING")
    {
        alert('order has not been processed, please process it');
    }
    else{
        let id = selected.childNodes[0].innerHTML;
        let url = "Order/Ready/"+id; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                alert("order has been readied, please wait for truck");
                getAllItems();
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
    }
}
function getLocations(){
     let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildDrop(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// gets all items
function getAllItems() {
    let loc=document.querySelector('#locations').value;
    let url = "Order/observe/"+loc;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        let place ='';
        switch(row.to){
            case(4):
                place="Saint John Retail";
                break;
            case(5):
                place="Sussex Retail";
                break;
            case(6):
                place="Moncton Retail";
                break;
            case(7):
                place="Dieppe Retail";
                break;
            case(8):
                place="Ormocto Retail";
                break;
            case(9):
                place="Fredricton Retail";
                break;
            case(10):
                place="Miramichi Retail";
                break;
            case(11):
                place="Curbside";
                break;
        }
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td value="+row.to+">"+place+"</td>";
        html+="<td>"+row.status+"</td>";
        html+="<td>"+row.ship+"</td>";
        if(row.emergency===1){
        html+="<td>EMERGENCY</td>"
        }
        else{
        html+="<td>No Emergency</td>";
    }
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function getQuantity(id){
    let url = "Inventory/get/"+id;
    let obj={
        id:id
    };
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                return resp.quantity;
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(obj);
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("select");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+(i+1)+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let place=document.querySelector("select").value;
    let emergency = document.querySelector("#emergency").checked;
    let date = new Date();
    let ship = date;
    let obj={
        place:place,
        emergency:emergency,
        date:date,
        ship:ship
    };
    let url = "Order/store/"+place;
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== 1) {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert('it finally worked');
            }
            getAllItems();
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
    alert("order for "+place+" has (not) been made");
}