let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#get").addEventListener("click", getAllItems);
    document.querySelector("#DeleteButton").addEventListener("click", removeItem);
    document.querySelector("#finalize").addEventListener("click", SubmitOrder);
    document.querySelector("table").addEventListener("click", handleRowClick);
    // add event handler for selections on the table
};
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    addOrUpdate="update";
}
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
function SubmitOrder(){
    let loc = document.querySelector("#locations").value;
    let url = "Order/submit/"+loc; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp!=="1") {
                alert("oh no, something is wrong with the GET ...");
            } else {
                alert("order has been submitted, returning to dashboard");
                window.location.replace("dashboard.php");
            }
        }
    };
    xmlhttp.open("PUT", url, true);
    xmlhttp.send();
    }
function getLocations(){
     let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildDrop(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// gets all items
function getAllItems() {
    let loc=document.querySelector('#locations').value;
    console.log(loc);
    let url = "Order/saved/"+loc;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.wholecost+"</td>";
        html+="<td>"+row.quantity+"</td>";
        html += "</tr>";
    }
}
theTable.innerHTML = html;
}
function getQuantity(id){
    let url = "Inventory/get/"+id;
    let obj={
        id:id
    };
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                return resp.quantity;
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(obj);
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("select");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+(i+1)+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let place=document.querySelector("select").value;
    let emergency = document.querySelector("#emergency").checked;
    let date = new Date();
    let ship = date;
    let obj={
        place:place,
        emergency:emergency,
        date:date,
        ship:ship
    };
    let url = "Order/store/"+place;
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== 1) {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert('it finally worked')
            }
            getAllItems();
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
    alert("order for "+place+" has (not) been made");
}
function removeItem() {
    let loc = document.querySelector("#locations").value;
    let row=document.querySelector(".highlighted");
    let id = row.querySelectorAll("td")[0].innerHTML;
    let obj={
        id:id,
        loc:loc
    };
    // AJAX
    let url = "Order/Remove"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== "1") {
                alert("ratio");
                console.log(resp);
            } else {
                console.log(resp);
                getAllItems();
            }
        }
    };
    xmlhttp.open("DELETE", url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
    }


