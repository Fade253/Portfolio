let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    // add event handlers for buttons
    document.querySelector("#AddButton").addEventListener("click", addUser);
    document.querySelector("#UpdateButton").addEventListener("click", updateUser);
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#CancelButton").addEventListener("click", hideUpdatePanel);
    document.querySelector("#backBtn").addEventListener("click", backButton)
    // add event handler for selections on the table
    document.querySelector("table").addEventListener("click", handleRowClick);
    hideUpdatePanel();
    getAllItems()
};
function backButton()
{
    window.location.replace("index.php");
}
//resets update when adding
function resetUpdatePanel() {
    document.querySelector("#id").value = "";
    document.querySelector("#name").value="";
    document.querySelector("#address").value = "";
    document.querySelector("#post").value="";
    document.querySelector("#phone").value="506";
    document.querySelector("#dow").value="";
    document.querySelector("distance").value=0;
}
//handles when a row is clicked
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    document.querySelector("#UpdateButton").removeAttribute("disabled");
    fillUpdatePanel();
    addOrUpdate="update";
}

// gets all items
function getAllItems() {
    let url = "Item/get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
                hideUpdatePanel();
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    // disable Delete and Update buttons
    document.querySelector("#UpdateButton").setAttribute("disabled", "disabled");
}

// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html += "<td>" + row.id + "</td>";
        html += "<td>" + row.name + "</td>";
        html += "<td>" + row.sku + "</td>";
        html += "<td>" + row.description +"</td>";
        html += "<td>" + row.category + "</td>";
        html += "<td>" + row.weight + "</td>";
        html += "<td>" + row.wholecost + "</td>";
        html += "<td>" + row.retail + "</td>";
        html += "<td>" + row.supplier + "</td>";
        html+="<td>"+row.caseSize+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
//clears any selected elements
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
//hides update panel when loading data
function hideUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.add("hidden");
}
//reveals hen adding or updating
function showUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.remove("hidden");
}
//fills with information of clicked row
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    let id = items[0].innerHTML;
    let name = items[1].innerHTML;
    let sku = items[2].innerHTML;
    let desc= items[3].innerHTML;
    let cat=items[4].innerHTML;
    let weight=items[5].innerHTML;
    let whole= items[6].innerHTML;
    let ret=items[7].innerHTML;
    let supplier=items[8].innerHTML;
    let cases = items[9].innerHTML;
    document.querySelector("#id").value=id;
    document.querySelector("#name").value=name;
    document.querySelector("#sku").value=sku;
    document.querySelector("#category").value = cat;
    document.querySelector("#desc").value=desc;
    document.querySelector("#weight").value=weight;
    document.querySelector("#whole").value = whole;
    document.querySelector("#retail").value=ret;
    document.querySelector("#supplier").value=supplier;
    document.querySelector("#case").value=cases;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let id;
    if(document.querySelector("#id").value!==""){
        id=document.querySelector("#id").value;
    }
    else{
        id=0;
    }
    let name = document.querySelector("#name").value;
    let cat = document.querySelector("#category").value;
    let desc = document.querySelector("#desc").value;
    let sku = document.querySelector("#sku").value;
    let weight = document.querySelector("#weight").value;
    let whole=document.querySelector("#whole").value;
    let ret = document.querySelector("#retail").value;
    let caseSize=document.querySelector("#case").value;
    let supp=document.querySelector("#supplier").value;
    let obj = {
        id:id,
        name: name,
        desc:desc,
        cat: cat,
        sku: sku,
        weight: weight,
        whole: whole,
        ret: ret,
        caseSize: caseSize,
        supp:supp
    };
    console.log(obj);
    // Make AJAX call to add or update the record in the database.
    let url = "Item/Edit/"+id;
    let method = (addOrUpdate === "add") ? "POST":"PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== '1') {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert('it finally worked');
            }
            getAllItems();
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
//switches wide variable
function addUser() {
    addOrUpdate = "add";
    showUpdatePanel();
    document.querySelector("#id").disabled=false;
}
function updateUser() {
    addOrUpdate="update";
    showUpdatePanel();
    fillUpdatePanel();
}

function setIDFieldState(val) {
    let idInput = document.querySelector("#id");
    if (val) {
        idInput.removeAttribute("disabled");
    }
}


