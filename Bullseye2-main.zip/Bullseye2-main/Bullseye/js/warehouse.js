let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#GetButton").addEventListener("click", getAllItems);
    document.querySelector("#move").addEventListener("click", getWarehouseInventory);
    document.querySelector("#reorder").addEventListener("change", getWarehouseInventory);
    document.querySelector("table").addEventListener("click", handleRowClick);
    // add event handler for selections on the table
};
function hideUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.add("hidden");
}
//reveals hen adding or updating
function showUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.remove("hidden");
}
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    let id = items[0].innerHTML;
    let quantity=items[2].innerHTML;
    document.querySelector("#item").value=id;
    document.querySelector("#reorder").value=quantity;
    
}
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    fillUpdatePanel();
    addOrUpdate="update";
}
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
function getAllUrlParams(url) {
  // get query string from url (optional) or window
  var queryString = url ? url.split('?')[1] : window.location.search.slice(1);
  // we'll store the parameters here
  var obj = {};
  // if query string exists
  if (queryString) {
    // stuff after # is not part of query string, so get rid of it
    queryString = queryString.split('#')[0];

    // split our query string into its component parts
    var arr = queryString.split('&');

    for (var i = 0; i < arr.length; i++) {
      // separate the keys and the values
      var a = arr[i].split('=');
      // set parameter name and value (use 'true' if empty)
      var paramName = a[0];
      var paramValue = typeof (a[1]) === 'undefined' ? true : a[1];

      // (optional) keep case consistent
      paramName = paramName.toLowerCase();
      if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();

      // if the paramName ends with square brackets, e.g. colors[] or colors[2]
      if (paramName.match(/\[(\d+)?\]$/)) {

        // create key if it doesn't exist
        var key = paramName.replace(/\[(\d+)?\]/, '');
        if (!obj[key]) obj[key] = [];

        // if it's an indexed array e.g. colors[2]
        if (paramName.match(/\[\d+\]$/)) {
          // get the index value and add the entry at the appropriate position
          var index = /\[(\d+)\]/.exec(paramName)[1];
          obj[key][index] = paramValue;
        } else {
          // otherwise add the value to the end of the array
          obj[key].push(paramValue);
        }
      } else {
        // we're dealing with a string
        if (!obj[paramName]) {
          // if it doesn't exist, create property
          obj[paramName] = paramValue;
        } else if (obj[paramName] && typeof obj[paramName] === 'string'){
          // if property does exist and it's a string, convert it to an array
          obj[paramName] = [obj[paramName]];
          obj[paramName].push(paramValue);
        } else {
          // otherwise add the property
          obj[paramName].push(paramValue);
        }
      }
    }
  }
  return obj;
}
// gets all items
function getAllItems() {
    let id=getAllUrlParams(window.location.href);
    console.log(id);
    let url = "Order/txn/"+id['id'];
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getWarehouseInventory(){
    let id = document.querySelector("#item").value;
    let url = "Item/Ware/"+id;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                addtoInput(JSON.parse(resp));
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function addtoInput(quantity){
    document.querySelector("#ware").value=quantity[0];
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let num = i+1;
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.quantity+"</td>";
        html+="<td><input type='checkbox' id='back"+num+"'></td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let items=[];
    let quantity=[];
    let table =document.querySelector('table');
    let row=table.querySelectorAll('tr');
    for (let i = 1; i<row.length; i++)
    {
        let item = document.querySelector("#back"+i);
        if(item.checked ===true){
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[2].textContent);
            quantity.push(val);
        }
    }
    let obj={
        item:items,
        quantity:quantity
    };
    console.log(items);
    if(items.length!==0){
    let back = getAllUrlParams();
    let url = "Order/backorder/"+back['id'];
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert('it finally worked');
                process();
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
    alert("item was put to backorder");
    }
    else{
        alert('no backorders input, begin putting order together at warehouse');
        process();
    }
}
function process(){
    let id=getAllUrlParams(window.location.href);
    let items=[];
    let quantity=[];
    let table =document.querySelector('table');
    let row=table.querySelectorAll('tr');
    for (let i = 1; i<row.length; i++)
    {
        for (let i = 1; i<row.length;i++){
        let item = document.querySelector("#back"+i);
        if(item.value ===false){
            items.push(row[i].cells[0].textContent);
            let val = parseInt(row[i].cells[2].textContent);
            quantity.push(val);
        }
    }
    }
    let obj={
        item:items,
        quantity:quantity
    };
    let url='process/ready/'+id['id'];
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                addtoInput(JSON.parse(resp));
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(obj));
}


