let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    // add event handlers for button
    document.querySelector("#backBtn").addEventListener("click", backButton);
    document.querySelector("#get").addEventListener("click", getReports);
    document.querySelector("#recipt").addEventListener("click", getRecipt);
    // add event handler for selections on the table
    document.querySelector("table").addEventListener("click", handleRowClick);
    getLocations();
};
function backButton()
{
    window.location.replace("index.php");
}
//resets update when adding
//handles when a row is clicked
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    addOrUpdate="update";
}
function getLocations(){
    let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildDrop(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getRecipt(){
    let selected=document.querySelector(".highlighted");
    let row=selected.querySelectorAll("td");
    let id=row[0].innerHTML;
    console.log(id);
    let url = "Order/txn/"+id;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildRecipt(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("#loc");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+(i+1)+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
// gets all items
function getReports(){
    let type=document.querySelector("#report").value;
    let param='';
    let date1=getDate(document.querySelector("#start").value);
    switch(type){
            case('1'):
                param='BackOrder';
                break;
            case('2'):
                param='StoreOrder';
                break;
            case('3'):
                param='Loss';
                break;
            case('4'):
                param='Inventory';
                date1=document.querySelector("#loc").value;
                break;
            case('5'):
                param='Order';
                break;
            case('6'):
                param='Emergency';
                break;
            case('7'):
                param='Users';
                break;
            case('8'):
                param='Supplier';
                break;
            case('9'):
                param='Delivery';
                break;
    }
    let url = "Report/"+param+"/"+date1; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                console.log(resp);
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function getDate(dateobj){
        let newdate=dateobj.replace('-', '');
        let date=newdate.replace('-', '');
        return date;
}
function buildInventory(text){
    console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>ID</th>\n\
<th>Username</th>\n\
<th>First Name</th>\n\
<th>Last Name</th>\n\
<th>Email</th>\n\
<th>position</th>\n\
<th>Reorder</th>\n\
<th>Site</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        let loc=getLoc(row.location);
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.retail+"</td>";
        html+="<td>"+row.wholecost+"</td>";
        html+="<td>"+row.quantity+"</td>";
        html+="<td>"+row.caseSize+"</td>";
        html+="<td>"+row.reorder+"</td>";
        html+="<td>"+loc+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML=html;
}
function buildRecipt(text){
    console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>Item</th>\n\
<th>Name</th>\n\
<th>Retail</th>\n\
<th>WholeSale</th>\n\
<th>Weight</th>\n\
<th>Quantity</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.retail+"</td>";
        html+="<td>"+row.wholecost+"</td>";
        html+="<td>"+row.weight+"</td>";
        html+="<td>"+row.quantity+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML=html;
}
function buildUsers(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>ID</th>\n\
<th>Username</th>\n\
<th>First Name</th>\n\
<th>Last Name</th>\n\
<th>Email</th>\n\
<th>position</th>\n\
<th>Site</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        let site=getLoc(row.site);
        let position=getPos(row.position);
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html += "<td>" + row.username + "</td>";
        html += "<td>" + row.first + "</td>";
        html += "<td>" + row.last + "</td>";
        html += "<td>" + row.email + "</td>";
        html += "<td>" + position + "</td>";
        html += "<td>" + site + "</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function buildOrder(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>ID</th>\n\
<th>To</th>\n\
<th>From</th>\n\
<th>Status</th>\n\
<th>type</th>\n\
<th>Created Date</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.to+"</td>";
        html+="<td>"+row.from+"</td>";
        html+="<td>"+row.status+"</td>";
        html+="<td>"+row.type+"</td>";
        html+="<td>"+row.created+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function buildTable9(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    theTable.innerHTML="";
    theTable.innerHTML="<tr>\n\
<th>DeliveryID</th>\n\
<th>TxnID</th>\n\
<th>To</th>\n\
<th>From</th>\n\
<th>Distance</th>";
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        let loc1=getLoc(row.feild3);
        let loc2=getLoc(row.feild4);
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.feild1+"</td>";
        html+="<td>"+row.feild2+"</td>";
        html+="<td>"+loc1+"</td>";
        html+="<td>"+loc2+"</td>";
        html+="<td>"+row.feild5+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function getLoc(loc){
    let place='';
    switch(loc){
        case(1):
        place="Warehouse";
        break;
        case(2):
        place="Warehouse Bay";
        break;
        case(3):
        place="Bullseye HQ";
        break;
        case(4):
                place="Saint John Retail";
                break;
            case(5):
                place="Sussex Retail";
                break;
            case(6):
                place="Moncton Retail";
                break;
            case(7):
                place="Dieppe Retail";
                break;
            case(8):
                place="Ormocto Retail";
                break;
            case(9):
                place="Fredricton Retail";
                break;
            case(10):
                place="Miramichi Retail";
                break;
            case(11):
                place="Curbside";
                break;
            case(9999):
                place="Acadia Headquarters";
                break;
    }
    return place;
}
function getPos(loc){
    let place='';
    switch(loc){
        case(1):
        place="Regional Manager";
        break;
        case(2):
        place="Financial Manager";
        break;
        case(3):
        place="Store Manager";
        break;
        case(4):
                place="Warehouse Manager";
                break;
            case(5):
                place="Trucking/Delivery";
                break;
            case(6):
                place="Warehouse Employee";
                break;
            case(99999999):
                place="Administrator";
                break;
    }
    return place;
}
// builds wth text from getAllItems
function buildTable(text) {
    let type=document.querySelector("#report").value;
    switch(type){
            case('1'):
                buildOrder(text);
                break;
            case('2'):
                buildOrder(text);
                break;
            case('3'):
                buildOrder(text);
                break;
            case('4'):
                buildInventory(text);
                break;
            case('5'):
                buildOrder(text);
                break;
            case('6'):
                buildOrder(text);
                break;
            case('7'):
                buildUsers(text);
                break;
            case('8'):
                buildOrder(text);
                break;
            case('9'):
                buildTable9(text);
                break;
    }
}
//clears any selected elements
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}



