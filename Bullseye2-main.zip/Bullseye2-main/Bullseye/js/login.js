window.onload = function () {
    //document.querySelector("form").addEventListener("submit", checkInputs);
    //Checks if the backbtn exists, if not do the other two.
    if (document.querySelector("#backBtn"))
    {
     document.querySelector("#backBtn").addEventListener("click", backButton);
    }
    if(document.querySelector("#loginBtn"))
    {
    document.querySelector("#loginBtn").addEventListener("click", loginAccount);
    }
    if(document.querySelector("#verify")){
        document.querySelector("#verify").addEventListener("click", ConfirmEmail);
    }
    if(document.querySelector("#confirm")){
        document.querySelector("#confirm").addEventListener("click", ChangePassword);
    }
};

function backButton()
{
    let date=getDate();
    let obj={
        "date":date
    };
    let url = "User/logout/"+0;
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
     xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
                console.log(resp);
                if (resp === "1")
                {
                   alert("successfully logged out");
                   window.location.replace("index.php");
                }
        }
    };
    xmlhttp.open(method, url, true); // method is either POST or PUT
    xmlhttp.send(JSON.stringify(obj));
}
function loginAccount()
{
    let date=getDate();
    let username = document.querySelector("#username").value;
    let password = document.querySelector("#password").value;
    let url = "User/login"; // REST-style: URL refers to an entity or collection, not an action
    let xmlhttp = new XMLHttpRequest();
    //let url="User/Login/"+username
    let obj = {
        "username": username,
        "password": password,
        "date":date
    };
    let method = "POST";
     xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
                console.log(resp);
                if (resp === "1")
                {
                   alert("successfully logged in")
                   window.location.replace("dashboard.php");
                }
                else{
                    alert("invalid user or password, if you are signing in again please change your password so it is encrypted")
                }
        }
    }
    xmlhttp.open(method, url, true); // method is either POST or PUT
    xmlhttp.send(JSON.stringify(obj));
  }
    function getDate(){
        let dateobj=new Date();
        let year = dateobj.getFullYear();
        let month=dateobj.getMonth();
        if(month.toString().length < 2){
           month="0"+month;
        }
        let day=dateobj.getDay();
        if(day.toString().length < 2){
        day="0"+day;
        }
        let date=year+""+month+""+day;
        return date;
        }
    function ConfirmEmail()
{
    let email = document.querySelector("#email").value;
    console.log(email);
    let url = "User/email/" + email; // REST-style: URL refers to an entity or collection, not an action
    let xmlhttp = new XMLHttpRequest();
    //let url="User/Register/"+username;
    let method = "POST";
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp === "1")
            {
              window.location.replace("password.php");
            }
            else
            {
                console.log(resp);
                alert("error, no email found or error");
            }
        }
    };
    xmlhttp.open(method, url, true); // method is either POST or PUT
    xmlhttp.send();
    }
    function ChangePassword(){
        let obj={
            "date":getDate()
        };
        let password = document.querySelector("#password2").value;
        if(password!==document.querySelector("#password").value){
            alert("passwords do not match");
        }
        else if(!password.length > 8 || !password.match(/.+?(?=[A-Za-z0-9\!\#\$\%\^\&\*])/)){
            alert("we insist your password is at least 8 characters and has a special character");
    }
        else {
            let url = "User/Password/"+password; // REST-style: URL refers to an entity or collection, not an action
          let xmlhttp = new XMLHttpRequest();
          let method = "POST";
          xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp === "1")
            {
              console.log(resp);
              alert("password changed, returning to login");
              window.location.replace("index.php");
            }
            else
            {
                console.log(resp);
                alert("error, no email found or error");
            }
        }
    };
    xmlhttp.open(method, url, true); // method is either POST or PUT
    xmlhttp.send(JSON.stringify(obj));
    }
    }