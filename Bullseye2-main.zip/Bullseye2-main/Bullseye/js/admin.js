let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    // add event handlers for buttons
    document.querySelector("#GetButton").addEventListener("click", getAllItems);
    document.querySelector("#AddButton").addEventListener("click", addUser);
    document.querySelector("#DeleteButton").addEventListener("click", deleteUser);
    document.querySelector("#UpdateButton").addEventListener("click", updateUser);
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#CancelButton").addEventListener("click", hideUpdatePanel);
    // add event handler for selections on the table
    document.querySelector("table").addEventListener("click", handleRowClick);
    hideUpdatePanel();
    getLocations();
};
//resets update when adding
function resetUpdatePanel() {
    document.querySelector("#first").value = "";
    document.querySelectorAll("option")[0].selected = true; // select first one
    document.querySelector("#last").value = "";
    document.querySelector("#password").value="";
    document.querySelector("#site").value=0;
    document.querySelector("#position").value=0;
}
//handles when a row is clicked
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    document.querySelector("#DeleteButton").removeAttribute("disabled");
    document.querySelector("#UpdateButton").removeAttribute("disabled");
    fillUpdatePanel();
    document.querySelector("#first").disabled=true;
    addOrUpdate="update";
}
function backButton()
{
    let date=getDate();
    let obj={
        "date":date
    };
    let url = "User/logout/"+0;
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
     xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
                console.log(resp);
                if (resp === "1")
                {
                   alert("successfully logged out");
                   window.location.replace("index.php");
                }
        }
    };
    xmlhttp.open(method, url, true); // method is either POST or PUT
    xmlhttp.send(JSON.stringify(obj));
}
function getDate(){
        let dateobj=new Date();
        let year = dateobj.getFullYear();
        let month=dateobj.getMonth();
        if(month.toString().length < 2){
           month="0"+month;
        }
        let day=dateobj.getDay();
        if(day.toString().length < 2){
        day="0"+day;
        }
        let date=year+""+month+""+day;
        return date;
        }

// gets all items
function getAllItems() {
    let url = "Admin/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
                hideUpdatePanel();
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    // disable Delete and Update buttons
    document.querySelector("#DeleteButton").setAttribute("disabled", "disabled");
    document.querySelector("#UpdateButton").setAttribute("disabled", "disabled");
}
function getLocations(){
     let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildDrop(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("#site");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+(i+1)+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html += "<td>" + row.username + "</td>";
        html += "<td>" + row.password + "</td>";
        html += "<td>" + row.first + "</td>";
        html += "<td>" + row.last + "</td>";
        html += "<td>" + row.email + "</td>";
        html += "<td>" + row.active + "</td>";
        html += "<td>" + row.position + "</td>";
        html += "<td>" + row.site + "</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
//clears any selected elements
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
//hides update panel when loading data
function hideUpdatePanel() {
    document.getElementById("AddUpdatePanel").classList.add("hidden");
}
//reveals hen adding or updating
function showUpdatePanel() {
    document.querySelector("#first").value = "";
    document.querySelector("#last").value = "";
    document.querySelector("#password").value = "";
    document.querySelector("#permission").value=0;
    document.querySelector("#site").value=0;
    document.getElementById("AddUpdatePanel").classList.remove("hidden");
}
//fills with information of clicked row
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    let id = items[0].innerHTML;
    let user = items[1].innerHTML;
    let first = items[3].innerHTML;
    let last = items[4].innerHTML;
    let pass=items[2].innerHTML;
    let pos=items[7].innerHTML;
    let site = items[8].innerHTML;
    document.querySelector("#id").value=id;
    document.querySelector("#user").value=user;
    document.querySelector("#first").value = first;
    document.querySelector("#password").value = pass;
    document.querySelector("#last").value = last;
    document.querySelector("#permission").value=pos;
    document.querySelector("#site").value=site;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let date=getDate();
    let id;
    if(document.querySelector("#id").value===""){
        id=0;
    }
    else{
        id=document.querySelector("#id").value;
    }
    let first = document.querySelector("#first").value;
    let last = document.querySelector("#last").value;
    let pass= document.querySelector("#password").value;
    let position=document.querySelector("#permission").value;
    let site = document.querySelector("#site").value;
    console.log(site);
    let obj = {
        id:id,
        first: first,
        last: last,
        password: pass,
        position:position,
        site: site,
        date: date
    };
    // Make AJAX call to add or update the record in the database.
    let url = "Admin/Register/"+first;
    let method = (addOrUpdate === "add") ? "POST":"PUT";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== '1') {
                console.log(resp);
                alert("Update did not want to update");
            } else {
                getAllItems();
            }
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
//sets user to locked
function deleteUser() {
    let date=getDate();
    let obj={
        date:date
    };
    let row = document.querySelector(".highlighted"); // we know there's only one
    let user = row.querySelectorAll("td")[1].innerHTML;
    console.log(user);
    // AJAX
    let url = "Admin/Delete/" + user; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== '1') {
                alert("An Error has occured");
            } else {
                console.log(resp);
                getAllItems();
            }
        }
    };
    xmlhttp.open("PUT", url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
    }
//switches wide variable
function addUser() {
    addOrUpdate = "add";
    showUpdatePanel();
    document.querySelector("#first").disabled=false;
}
function updateUser() {
    addOrUpdate="update";
    showUpdatePanel();
    fillUpdatePanel();
}

function setIDFieldState(val) {
    let idInput = document.querySelector("#username");
    if (val) {
        idInput.removeAttribute("disabled");
    }
}
/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */


