let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#get").addEventListener("click", getAllItems);
    document.querySelector("#finalize").addEventListener("click", confirmContents);
    if(document.querySelector("#confirm")){
    document.querySelector("#confirm").addEventListener("click", confirmOrder);
}
if (document.querySelector("#ready")){
    document.querySelector("#ready").addEventListener("click", ReadyOrder);
    }
    document.querySelector("table").addEventListener("click", handleRowClick);
    if (document.querySelector("#loc")){
    document.querySelector("#loc").addEventListenr("click", getLocations);
}
    // add event handler for selections on the table
};
function confirmOrder(){
    let order=document.querySelector(".highlighted");
    let id=order.childNodes[0].innerHTML;
    window.location.replace("Store.php?id="+id);
}
function confirmContents(){
    let order=document.querySelector(".highlighted");
    let tds=order.querySelectorAll("td");
    let id=tds[0].innerHTML;
    let loc=tds[4].innerHTML;
    let place = convertToNum(loc);
    window.location.replace("Confirmation.php?id="+id+"&loc="+place);
}
function convertToNum(loc){
    let place =0
switch(loc){
            case('Saint John Retail'):
                place=4;
                break;
            case("Sussex Retail"):
                place=5;
                break;
            case("Moncton Retail"):
                place=6;
                break;
            case("Dieppe Retail"):
                place=7;
                break;
            case("Ormocto Retail"):
                place=8;
                break;
            case("Fredricton Retail"):
                place=9;
                break;
            case("Miramichi Retail"):
                place=10;
                break;
        }
        return place;
}
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    // enable Delete and Update buttons
    addOrUpdate="update";
}
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
function ReadyOrder(){
    let selected = document.querySelector(".highlighted");
    let status = selected.childNodes[2].innerHTML;
    console.log(status);
    if(status!=="PROCESSING")
    {
        alert('order has not been processed, please process it');
    }
    else{
        let id = selected.childNodes[0].innerHTML;
        let url = "Order/Ready/"+id; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                alert("order has been readied, please wait for truck");
                getAllItems();
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
    }
}
function getLocations(){
    let location = document.querySelector("#location").value;
    if(location ===""){
     let url = "Location/Get"; // file name or server-side process name
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildDrop(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
}
function getAllUrlParams(url) {
  // get query string from url (optional) or window
  var queryString = url ? url.split('?')[1] : window.location.search.slice(1);
  // we'll store the parameters here
  var obj = {};
  // if query string exists
  if (queryString) {
    // stuff after # is not part of query string, so get rid of it
    queryString = queryString.split('#')[0];

    // split our query string into its component parts
    var arr = queryString.split('&');

    for (var i = 0; i < arr.length; i++) {
      // separate the keys and the values
      var a = arr[i].split('=');
      // set parameter name and value (use 'true' if empty)
      var paramName = a[0];
      var paramValue = typeof (a[1]) === 'undefined' ? true : a[1];

      // (optional) keep case consistent
      paramName = paramName.toLowerCase();
      if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();

      // if the paramName ends with square brackets, e.g. colors[] or colors[2]
      if (paramName.match(/\[(\d+)?\]$/)) {

        // create key if it doesn't exist
        var key = paramName.replace(/\[(\d+)?\]/, '');
        if (!obj[key]) obj[key] = [];

        // if it's an indexed array e.g. colors[2]
        if (paramName.match(/\[\d+\]$/)) {
          // get the index value and add the entry at the appropriate position
          var index = /\[(\d+)\]/.exec(paramName)[1];
          obj[key][index] = paramValue;
        } else {
          // otherwise add the value to the end of the array
          obj[key].push(paramValue);
        }
      } else {
        // we're dealing with a string
        if (!obj[paramName]) {
          // if it doesn't exist, create property
          obj[paramName] = paramValue;
        } else if (obj[paramName] && typeof obj[paramName] === 'string'){
          // if property does exist and it's a string, convert it to an array
          obj[paramName] = [obj[paramName]];
          obj[paramName].push(paramValue);
        } else {
          // otherwise add the property
          obj[paramName].push(paramValue);
        }
      }
    }
  }
  return obj;
}
// gets all items
function getAllItems() {
    let loc;
    if(!document.querySelector("#location")){
        getOrderByName();
    }
    else{
    let loca = document.querySelector("#location").value;
    loc=loca;
    let url = "Order/note/"+loc;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
}
function getOrderByName(){
    let name = getAllUrlParams();
    let param="";
    if(name['name'].includes("%20")){
        param=name['name'].replace("%20", " ");
        console.log(param);
    }
    let url = "Order/name/"+param;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        let place ='';
        let place2='';
        switch(row.to){
            case(4):
                place="Saint John Retail";
                break;
            case(5):
                place="Sussex Retail";
                break;
            case(6):
                place="Moncton Retail";
                break;
            case(7):
                place="Dieppe Retail";
                break;
            case(8):
                place="Ormocto Retail";
                break;
            case(9):
                place="Fredricton Retail";
                break;
            case(10):
                place="Miramichi Retail";
                break;
            case(11):
                place="Curbside";
                break;
        }
        switch(row.from){
            case(4):
                place2="Saint John Retail";
                break;
            case(5):
                place2="Sussex Retail";
                break;
            case(6):
                place2="Moncton Retail";
                break;
            case(7):
                place2="Dieppe Retail";
                break;
            case(8):
                place2="Ormocto Retail";
                break;
            case(9):
                place2="Fredricton Retail";
                break;
            case(10):
                place2="Miramichi Retail";
                break;
            case(11):
                place2="Curbside";
                break;
        }
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td value="+row.to+">"+place+"</td>";
        html+="<td>"+row.status+"</td>";
        html+="<td>"+row.ship+"</td>";
        html+="<td value="+row.from+">"+place2+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
function getQuantity(id){
    let url = "Inventory/get/"+id;
    let obj={
        id:id
    };
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                return resp.quantity;
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(obj);
}
function buildDrop(text) {
    let arr = JSON.parse(text); // get JS Objects
    let html = document.querySelector("select");
    let text2 ="";
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.active!==0){
        text2+="<option value="+(i+1)+">"+row.name+"</option>";
    }
    }
    html.innerHTML = text2;
}
// processes when done is clicked, getting data and sending an object for operation
function processForm() {
    // Get data from the form and build an object.
    let place=document.querySelector("select").value;
    let emergency = document.querySelector("#emergency").checked;
    let date = new Date();
    let ship = date;
    let obj={
        place:place,
        emergency:emergency,
        date:date,
        ship:ship
    };
    let url = "Order/store/"+place;
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp !== 1) {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert('it finally worked');
            }
            getAllItems();
            hideUpdatePanel();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}


