let addOrUpdate;
let ordercount=0;
let orderDate='';
// to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#DoneButton").addEventListener("click", processForm);
    document.querySelector("#search").addEventListener("change", getSearchItems);
    document.querySelector("#get").addEventListener("click", getAllItems);
    // add event handler for selections on the table
};
function getSearchItems() {
    let loc=document.querySelector('#locations').value;
    let search=document.querySelector('#search').value;
    if(search===''){
        getAllItems();
    }
    else{
        
    let obj={
        location:loc
    };
    let url = "Item/search/"+search;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                console.log(resp);
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("POST", url, true);
    xmlhttp.send(JSON.stringify(obj));
    }
}
// gets all items
function getAllItems() {
    let loc=document.querySelector('#locations').value;
    let url = "Item/get/"+loc;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
// builds wth text from getAllItems
function buildTable(text) {
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        let num = i+1;
        if(row.active!==0){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.name+"</td>";
        html+="<td>"+row.retail+"</td>";
        html+="<td>"+row.wholecost+"</td>";
        html+="<td>"+row.quantity+"</td>";
        html+="<td>"+row.caseSize+"</td>";
        html += "<td><input id='cases"+num+"' type='number' value=0></td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
// processes when done is clicked, getting data and sending an object for operation
function changeInventory(){
    let items= [];
    let quantity=[];
    let bool=document.querySelector("#ret").value;
    let method = "PUT";
    let table = document.querySelector("table");
    let row=table.querySelectorAll("tr");
    for (let i = 1; i<row.length;i++){
        let item = document.querySelector("#cases"+i);
        if(item.value > 0){
            items.push(row[i].cells[0].textContent);
            let quan = parseInt(item.value);
            quantity.push(quan);
        }
    }
    let obj={
        items:items,
        quantity:quantity,
        bool:bool
    };
    let url = "Damage/items";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                console.log(resp);
                alert("there was ether another error, or the same error from last time");
            } else {
                alert('inventory has been updated');
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}
function processForm() {
    // Get data from the form and build an object.
    let place=document.querySelector("#locations").value;
    let type = document.querySelector("#type").value;
    let note = document.querySelector("#notes").value;
    let obj={
        place:place,
        type:type,
        note:note
    };
    let url = "Damage/return";
    let method = "POST";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0 || resp!=="1") {
                console.log(resp);
                alert("it refused despite it being correct");
            } else {
                alert(type + ' has been reported');
                changeInventory();
            }
            getAllItems();
        }
    };
    xmlhttp.open(method, url, true); // must be POST
    xmlhttp.send(JSON.stringify(obj));
}

