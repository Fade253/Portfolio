let addOrUpdate; // to track whether we're doing an add or an update
//applies buttons with methods
window.onload = function () {
    document.querySelector("#pickup").addEventListener("click", pickup);
    document.querySelector("#transport").addEventListener("click", transport);
    document.querySelector("#deliver").addEventListener("click", Deliver);
    document.querySelector("#cancel").addEventListener("click", Cancel);
    document.querySelector("#accept").addEventListener("click", accept);
    document.querySelector("table").addEventListener("click", handleRowClick);
    // add event handler for selections on the table
    getAllItems();
};

// gets all items
function getAllItems() {
    let url = "Order/get";
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                buildTable(resp);
            }
        }
    };
    xmlhttp.open("GET", url, true);
    xmlhttp.send();
}
function transport() {
    let id=document.querySelector('#id').value;
    let url = "Order/transport/"+id;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                getAllItems();
            }
        }
    };
    xmlhttp.open("PUT", url, true);
    xmlhttp.send();
}
function Cancel() {
    let selected = document.querySelector(".highlighted");
    let items=selected.querySelectorAll("td");
    if(items[3].innerHTML==="SUBMITTED" || items[3].innerHTML==="PROCESSING"){
    let id=document.querySelector('#id').value;
    let url = "Order/Cancel/"+id;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                getAllItems();
            }
        }
    };
    xmlhttp.open("PUT", url, true);
    xmlhttp.send();
}
else{
    alert("it is too late to cancel an order already on its way")
}
}
function accept() {
    let id=document.querySelector('#id').value;
    window.location.replace("Confirmation.php?id="+id);
}
function Deliver() {
    let id=document.querySelector('#id').value;
    let url = "Order/Deliver/"+id;
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState === 4 && xmlhttp.status === 200) {
            let resp = xmlhttp.responseText;
            console.log(resp);
            if (resp.search("ERROR") >= 0) {
                alert("oh no, something is wrong with the GET ...");
            } else {
                getAllItems();
            }
        }
    };
    xmlhttp.open("PUT", url, true);
    xmlhttp.send();
}
function pickup() {
    window.location.replace('acadia.php')
}
function handleRowClick(e) {
    //add style to parent of clicked cell
    clearSelections();
    e.target.parentElement.classList.add("highlighted");
    fillUpdatePanel();
}
function fillUpdatePanel(){
    let selected = document.querySelector(".highlighted");
    let items = selected.querySelectorAll("td");
    console.log(items[0].innerHTML);
    let id = items[0].innerHTML;
    document.querySelector("#id").value=id;
}
function clearSelections() {
    let trs = document.querySelectorAll("tr");
    for (let i = 0; i < trs.length; i++) {
        trs[i].classList.remove("highlighted");
    }
}
// builds wth text from getAllItems
function buildTable(text) {
   console.log(text);
    let arr = JSON.parse(text); // get JS Objects
    let theTable = document.querySelector("table");
    let html = theTable.querySelector("tr").innerHTML;
    for (let i = 0; i < arr.length; i++) {
        let row = arr[i];
        if(row.status!=='CANCELLED'){
        html += "<tr>";
        html+="<td>"+row.id+"</td>";
        html+="<td>"+row.to+"</td>";
        html+="<td>"+row.from+"</td>";
        html+="<td>"+row.status+"</td>";
        html+="<td>"+row.type+"</td>";
        html+="<td>"+row.created+"</td>";
        html += "</tr>";
    }
    }
    theTable.innerHTML = html;
}
