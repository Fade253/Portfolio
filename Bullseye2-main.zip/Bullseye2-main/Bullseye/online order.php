<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <button id="get">Get items</button>
        <button id="DoneButton">Done</button>
        <button id='backBtn'>Log Out</button>
        <button id="DateButton">Click me before you confirm</button>
        <button id="checkOrder">have an order? find it here</button>
        <div>
             <div class="formLabel">Name:</div><input id="name">
         </div>
        <div>
             <div class="formLabel">Email:</div><input id="email">
        </div>
        <div>
             <div class="formLabel">Phone:</div><input id="phone">
        </div>
        <div>
            <div class="formLabel">Location</div>
            <select id="locations">
                <option value="4">Saint John</option>
                <option value="5">Sussex</option>
                <option value="6">Moncton</option>
                <option value="7">Dieppe</option>
                <option value="8">Oromocto</option>
                <option value="9">Fredricton</option>
                <option value="10">Miramichi</option>
            </select>
        </div>
        <div class="formLabel">Search: </div><input id="search">
            <table>
            <th>item</th>
            <th>Name</th>
            <th>Cost</th>
            <th>Weight</th>
            <th>Available quantity</th>
            <th>Amount to Order</th>
            </table>
        <script src="js/onlineOrder.js"></script>
    </body>
</html> 

