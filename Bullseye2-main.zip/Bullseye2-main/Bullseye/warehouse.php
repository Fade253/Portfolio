<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/warehouse.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="home">Home</button>
        <button id='GetButton'>Get Inventory</button>
        <button id='UpdateButton'>Update</button>
        <br>
        <button id="Order">Order</button>
        <div><div class='formLabel'>Search</div><input id='search' type='text'></div>
        <div id="AddUpdatePanel">
            <input id="id">            
            <div>
                <div class="formLabel">Item</div><input id="item">
            </div>
            <div>
                <div class="formLabel">Quantity</div><input id="reorder">
            </div>
            <div>
                <div class="formLabel">Warehouse Quantity</div><input id="ware">
            </div>
            <div>
                <button id="move">Check</button>
                <button id="CancelButton">BackOrder</button>
                <button id="DoneButton">Confirm Order</button>
            </div>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Check to add item to backorder</th>
            </tr>
        </table>
    </body>
</html>
