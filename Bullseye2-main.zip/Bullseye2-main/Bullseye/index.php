<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>

    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <div id="loginScreen">
            <div><label for="name">Username</label><input class="loginSpace" name="username" id="username"></div>
            <div><label for="password">Password</label><input class="loginSpace" name = "password" id="password" type="password"></div>
            <button id ="loginBtn" class="loginPageButton">Log in</button> 
            <a href="email.php" id="forgor">Forgot Password?</a>
            <a href="online order.php" id="forgor">Customer Order</a>
        </div>
        <script src="js/login.js"></script>
    </body>
</html> 
