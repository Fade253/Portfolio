<!DOCTYPE html>
<?php session_start()?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <select id="locations">
            <option value=<?php echo $_SESSION['site'];?>><?php echo $_SESSION['site']?></option>
        </select>
        <button id="get">Get Items</button>
        <button id="finalize">Submit</button>
        <button id="DeleteButton">Remove Item</button>
        <button id='backBtn'>Log Out</button>
        <div id="txnID"></div>
        <table>
                <th>ID</th>
                <th>To</th>
                <th>Cost</th>
                <th>Quantity ordered</th>
        </table>
        <script src="js/storeorder.js"></script>
    </body>
</html> 

