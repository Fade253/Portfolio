<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>

    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <div id="loginScreen">
            Enter your Email:
            <input id="email">
            <button id="verify">Verify</button>
        </div>
        <script src="js/login.js"></script>
    </body>
</html> 

