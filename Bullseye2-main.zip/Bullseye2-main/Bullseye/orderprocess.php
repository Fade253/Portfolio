<!DOCTYPE html>
<?php
session_start()
?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <button id="DoneButton">Done</button>
        <button id='backBtn'>Log Out</button>
        <button id='pickup'>Pickup</button>
        <button id='transport'>Transport</button><!-- comment -->
        <button id='deliver'>Deliver</button>
        <button id='accept'>accept</button>
        <button id='cancel'>cancel</button>
         <input id="location" type="text">
         <input id="id" type="text">
        <table>
            <tr>
            <th>ID</th>
            <th>to</th>
            <th>from</th>
            <th>status</th>
            <th>type</th>
            <th>made</th>
            </tr>
        </table>
        <script src="js/process.js"></script>
    </body>
</html> 
