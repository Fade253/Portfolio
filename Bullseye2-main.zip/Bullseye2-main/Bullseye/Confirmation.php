<?php session_start();?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/confirm.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="home">Home</button>
        <button id='GetButton'>Get Inventory</button>
        <button id="confirm">Confirm Order</button>
        <?php if(isset($_SESSION['site'])){
        ?>
        <input id="location" value=<?php echo $_SESSION['site'];?>>
        <?php
        }
        else{?>
            <input id="location">
            <button id="getLocation">click me before continueing</button>
        <?php
        }
        ?>
        <button id="Order">Order</button>
        <table>
            <tr>
                <th>ID</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Correct?</th>
            </tr>
        </table>
    </body>
</html>
