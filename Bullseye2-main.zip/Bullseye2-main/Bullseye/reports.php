 <!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <button id='get'>get Reports</button>
        <button id="recipt">Get Recipt for order</button>
        <button id='backBtn'>Log Out</button>
        <select id="loc">
            
        </select>
        <div>
            <div>startDate</div><input type="date" id="start"><!-- comment -->
        </div><!-- comment -->
        <select id="report">
            <option value="1">Back Order</option><!-- comment -->
            <option value="2">Store Order</option><!-- comment -->
            <option value="3">Loss/Damage/Returns</option><!-- comment -->
            <option value="4">Inventory</option><!-- comment -->
            <option value="5">Order</option><!-- \ -->
            <option value="6">Emergency Orders</option><!-- comment -->
            <option value="7">Users</option><!-- comment -->
            <option value="8">Supplier Order</option><!-- comment -->
            <option value="9">Delivery</option>
        </select>
        <table>
            
        </table>
        <script src="js/reports.js"></script>
    </body>
</html> 
