<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>System</title>
        <link rel="stylesheet" href="style/style.css">
        <script src="js/inventory.js"></script>
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <h1>Admin Area</h1>
        <button id='backBtn'>Log Out</button>
        <button id="home">Home</button>
        <button id='GetButton'>Get Inventory</button>
        <button id='UpdateButton'>Update</button>
        <br>
        <button id="Order">Order</button>
        <div>
            <select id="locations">
                
            </select>
        </div>
        <div><div class='formLabel'>Search</div><input id='search' type='text'></div>
        <div id="AddUpdatePanel">
            <input id="id">            
            <div>
                <div class="formLabel">Item</div><input id="item">
            </div>
            <div>
                <div class="formLabel">Reorder threshold</div><input id="reorder">
            </div>
            <div>
                <button id="DoneButton">Done</button>
                <button id="CancelButton">Cancel</button>
            </div>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Shelf Location</th>
                <th>Reorder</th>
                <th>Case Sizes</th>
            </tr>
        </table>
    </body>
</html>