<!DOCTYPE html>
<?php session_start();?>
<html>
    <head>
        <meta charset="utf-8">
        <title>Bullseye Inventory System</title>
        <link rel="stylesheet" href="style/style.css">
    </head>
    <body>
        <div class="logocent">
            <img id="logo" src="img/Logo.jpg" alt="Bullseye logo">
        </div>
        <?php if(!isset($_SESSION['site'])){
        }
        else{
        ?>
        <input id="location" value=<?php echo $_SESSION['site'];?>><!-- comment -->
        <?php
        }
        ?>
        <button id="get">Get Items</button>
        <?php if(isset($_SESSION['perm'])){?>
        <button id="confirm">Confirm items for order</button>
        <?php
        }
        ?>
        <button id="research">Search</button>
        <button id="DoneButton">Done</button>
        <button id="finalize">confirm order</button>
        <?php if(isset($_SESSION['perm'])){?>
        <button id="ready">Order is Ready for Pickup</button>
        <?php
        }
        ?>
        <button id='backBtn'>Log Out</button>
        <table>
                <th>ID</th>
                <th>To</th>
                <th>Status</th>
                <th>Information</th>
                <th>From</th>
        </table>
        <script src="js/onlineCheck.js"></script>
    </body>
</html>