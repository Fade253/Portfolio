# Store-Page
Java store page for monitors-does not use any money for transactions
TO RUN:
1:have glassfish installed on your device
2:run the script as part of this to put together a database in netbeans using jbdc
3:once the database is made hit run on the index
